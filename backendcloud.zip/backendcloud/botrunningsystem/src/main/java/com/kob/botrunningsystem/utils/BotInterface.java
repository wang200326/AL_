package com.kob.botrunningsystem.utils;

public interface BotInterface {
    Integer nextMove(String input);
}
