package com.kob.backend.service.pay;

import com.fasterxml.jackson.core.JsonProcessingException;

import java.util.Map;

public interface ReadOneOrdersService {
    public Map<String, String> readOneOrders() throws JsonProcessingException;
}
