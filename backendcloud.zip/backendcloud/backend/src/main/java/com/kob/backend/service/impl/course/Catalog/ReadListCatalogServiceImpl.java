package com.kob.backend.service.impl.course.Catalog;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.kob.backend.mapper.course.CatalogMapper;
import com.kob.backend.mapper.course.CourseMapper;
import com.kob.backend.pojo.course.Catalog;
import com.kob.backend.service.course.Catalog.ReadListCatalogService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class ReadListCatalogServiceImpl implements ReadListCatalogService {
    @Autowired
    private CatalogMapper catalogMapper;
    @Autowired
    private ObjectMapper objectMapper;
    @Autowired
    private CourseMapper courseMapper;

    @Override
    public Map<String, String> readListCatalog(Map<String, String> data) throws JsonProcessingException {
        Map<String, String> map = new HashMap<>();

        Integer course_id = Integer.valueOf(data.get("courseId"));
        QueryWrapper<Catalog> queryWrapper = new QueryWrapper<Catalog>();
        queryWrapper.eq("course_id", course_id);
        queryWrapper.orderByAsc("number");
        List<Catalog> list = catalogMapper.selectList(queryWrapper);

        if (courseMapper.selectById(course_id) == null) {
            map.put("error_message", "course_id对应的课程不存在");
            return map;
        }

        if (list.isEmpty()) {
            map.put("error_message", "没有当前课程对应的目录");
            return map;
        }

        String value = objectMapper.writeValueAsString(list);

        map.put("error_message", "success");
        map.put("List", value);
        return map;
    }
}
