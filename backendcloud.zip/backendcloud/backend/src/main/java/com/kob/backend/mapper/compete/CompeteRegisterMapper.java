package com.kob.backend.mapper.compete;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.kob.backend.pojo.compete.CompeteRegister;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface CompeteRegisterMapper extends BaseMapper<CompeteRegister> {
}
