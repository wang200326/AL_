package com.kob.backend.service.compete.competeProblem;

import com.fasterxml.jackson.core.JsonProcessingException;

import java.util.Map;

public interface ReadCompeteProblemService {
    public Map<String, String> readCompeteProblem(Map<String, String> data) throws JsonProcessingException;
}
