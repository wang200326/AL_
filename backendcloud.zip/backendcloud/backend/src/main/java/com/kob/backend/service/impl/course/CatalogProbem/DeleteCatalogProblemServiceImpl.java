package com.kob.backend.service.impl.course.CatalogProbem;

import com.kob.backend.mapper.course.CatalogProblemMapper;
import com.kob.backend.pojo.course.CatalogProblem;
import com.kob.backend.service.course.CatalogProblem.DeleteCatalogProblemService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

@Service
public class DeleteCatalogProblemServiceImpl implements DeleteCatalogProblemService {
    @Autowired
    private CatalogProblemMapper catalogProblemMapper;

    @Override
    public Map<String, String> deleteCatalogProblem(Map<String, String> data) {
        Map<String, String> map = new HashMap<>();

        String Id = data.get("id");
        if (Objects.equals(Id, "") || Id == null) {
            map.put("error_message", "id为空");
            return map;
        }
        Integer id = Integer.valueOf(Id);

        CatalogProblem catalogProblem =  catalogProblemMapper.selectById(id);

        if (catalogProblem == null) {
            map.put("error_message", "习题不存在");
            return map;
        }

        catalogProblemMapper.deleteById(catalogProblem);
        map.put("error_message", "success");
        return map;
    }
}
