package com.kob.backend.service.impl.postMessage.AboutMessage;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.kob.backend.mapper.postMessage.PostMessageMapper;
import com.kob.backend.pojo.postMessage.PostMessage;
import com.kob.backend.service.postMessage.AboutMessage.ReadMessageService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class ReadMessageServiceImpl implements ReadMessageService {
    @Autowired
    private PostMessageMapper postMessageMapper;
    @Autowired
    private ObjectMapper objectMapper;

    @Override
    public Map<String, String> readMessage() throws JsonProcessingException {
        Map<String, String> map = new HashMap<>();

        QueryWrapper<PostMessage> queryWrapper = new QueryWrapper<>();
        queryWrapper.orderByDesc("create_time");
        List<PostMessage> list =  postMessageMapper.selectList(queryWrapper);
        if (list.isEmpty()) {
            map.put("error_message", "无人发帖");
            return map;
        }

        String value = objectMapper.writeValueAsString(list);

        map.put("error_message", "success");
        map.put("list", value);
        return map;
    }
}
