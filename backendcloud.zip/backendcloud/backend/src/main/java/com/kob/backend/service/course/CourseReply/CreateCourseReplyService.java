package com.kob.backend.service.course.CourseReply;

import java.util.Map;

public interface CreateCourseReplyService {
    public Map<String, String> createCourseReply(Map<String, String> data);
}
