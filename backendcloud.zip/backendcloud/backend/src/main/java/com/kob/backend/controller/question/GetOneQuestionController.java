package com.kob.backend.controller.question;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.kob.backend.service.question.GetOneQuestionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
public class GetOneQuestionController {
    @Autowired
    private GetOneQuestionService getOneQuestionService;

    @PostMapping("/question/get/one/")
    public Map<String, String> getOne(@RequestParam Map<String, String> data) throws JsonProcessingException {
        return getOneQuestionService.getOne(data);
    }
}
