package com.kob.backend.mapper.course;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.kob.backend.pojo.course.CourseVideo;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface CourseVideoMapper extends BaseMapper<CourseVideo> {
}
