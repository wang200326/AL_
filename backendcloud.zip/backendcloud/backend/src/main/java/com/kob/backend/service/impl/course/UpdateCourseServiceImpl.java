package com.kob.backend.service.impl.course;

import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.kob.backend.mapper.course.CourseMapper;
import com.kob.backend.pojo.course.Course;
import com.kob.backend.service.course.UpdateCourseService;
import com.kob.backend.service.impl.course.uitl.Check;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

@Service
public class UpdateCourseServiceImpl implements UpdateCourseService {
    @Autowired
    private CourseMapper courseMapper;
    @Override
    public Map<String, String> updateCourse(Map<String, String> data) {
        Map<String, String> map = new HashMap<>();
        Integer id = Integer.valueOf(data.get("id"));
        String course_name = data.get("course_name");
        String photo = data.get("photo");
        Integer price = Integer.valueOf(data.get("price")); // 可以不写 但是前端不许传一个null进来
        String course_about = data.get("course_about");
        String words = data.get("words");

        // 进行错误判断
        Check obj = new Check();
        Map<String, String> new_map = obj.check(data);
        if (new_map != null) {
            return new_map;
        }

        UpdateWrapper<Course> updateWrapper = new UpdateWrapper<>();
        updateWrapper.set("course_name", course_name);
        updateWrapper.set("course_about", course_about);
        updateWrapper.set("photo", photo);
        updateWrapper.set("price", price);
        updateWrapper.set("words", words);
        updateWrapper.eq("id", id);

        courseMapper.update(null ,updateWrapper);
        map.put("error_message", "success");
        return map;
    }
}
