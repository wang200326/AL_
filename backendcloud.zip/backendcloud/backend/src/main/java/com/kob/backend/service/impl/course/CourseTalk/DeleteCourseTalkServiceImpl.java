package com.kob.backend.service.impl.course.CourseTalk;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.kob.backend.mapper.course.CourseReplyMapper;
import com.kob.backend.mapper.course.CourseTalkMapper;
import com.kob.backend.pojo.course.CourseReply;
import com.kob.backend.service.course.CourseTalk.DeleteCourseTalkService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

@Service
public class DeleteCourseTalkServiceImpl implements DeleteCourseTalkService {
    @Autowired
    private CourseTalkMapper courseTalkMapper;
    @Autowired
    private CourseReplyMapper courseReplyMapper;
    @Override
    public Map<String, String> deleteCourseTalk(Map<String, String> data) {
        Map<String, String> map = new HashMap<>();

        Integer id = Integer.valueOf(data.get("id"));

        courseTalkMapper.deleteById(id);
        QueryWrapper<CourseReply> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("card_id", id);
        courseReplyMapper.delete(queryWrapper);
        map.put("error_message", "success");

        return map;
    }
}
