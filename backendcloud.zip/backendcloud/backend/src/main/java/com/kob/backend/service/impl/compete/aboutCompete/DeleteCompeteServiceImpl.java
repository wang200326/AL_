package com.kob.backend.service.impl.compete.aboutCompete;

import com.kob.backend.mapper.compete.CompeteMapper;
import com.kob.backend.service.compete.aboutCompete.DeleteCompeteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

@Service
public class DeleteCompeteServiceImpl implements DeleteCompeteService {
    @Autowired
    private CompeteMapper competeMapper;


    @Override
    public Map<String, String> deleteCompete(Map<String, String> data) {
        Map<String, String> map = new HashMap<>();

        Integer id = Integer.valueOf(data.get("id"));

        competeMapper.deleteById(id);

        map.put("error_message", "success");
        return map;
    }
}
