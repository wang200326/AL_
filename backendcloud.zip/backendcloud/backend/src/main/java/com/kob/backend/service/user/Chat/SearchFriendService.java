package com.kob.backend.service.user.Chat;

import java.util.Map;

public interface SearchFriendService { // 按名字搜索用户
    public Map<String, String> searchFriend(Map<String, String> data);
}
