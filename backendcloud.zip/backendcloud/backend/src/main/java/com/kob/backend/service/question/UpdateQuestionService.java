package com.kob.backend.service.question;

import java.util.Map;

public interface UpdateQuestionService {
    public Map<String, String> update(Map<String, String> data);
}
