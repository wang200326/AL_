package com.kob.backend.service.compete.competeProblem;

import java.util.Map;

public interface CreateCompeteProblemService {
    public Map<String, String> createCompeteProblem(Map<String, String> data);
}
