package com.kob.backend.service.course.Video;

import com.fasterxml.jackson.core.JsonProcessingException;

import java.util.Map;

public interface ReadOneCourseVideoService {
    public Map<String, String> readOneVideo(Map<String, String> data) throws JsonProcessingException;
}
