package com.kob.backend.service.question.Video;

import java.util.Map;

public interface CreateProblemVideoService {
    public Map<String, String> createProblemVideo(Map<String, String> data);
}
