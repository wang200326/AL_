package com.kob.backend.service.question;


import java.util.Map;

public interface AddQuestionService {
    public Map<String, String> add(Map<String, String> data);
}
