package com.kob.backend.service.impl.postMessage.MessageLike;

import com.kob.backend.mapper.postMessage.MessageLikeMapper;
import com.kob.backend.mapper.postMessage.PostMessageMapper;
import com.kob.backend.pojo.postMessage.MessageLike;
import com.kob.backend.pojo.postMessage.PostMessage;
import com.kob.backend.service.postMessage.MessageLike.UpdateMessageLikeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

@Service
public class UpdateMessageLikeServiceImpl implements UpdateMessageLikeService {
    @Autowired
    private MessageLikeMapper messageLikeMapper;
    @Autowired
    private PostMessageMapper postMessageMapper;
    @Override
    public Map<String, String> updateMessageLike(Map<String, String> data) {
        Map<String, String> map = new HashMap<>();

        Integer id = Integer.valueOf(data.get("id"));

        MessageLike messageLike = messageLikeMapper.selectById(id);

        if (messageLike.getStatus() == 0) { // 说明这次是点赞
            messageLike.setStatus(1);
            messageLikeMapper.updateById(messageLike);

            PostMessage postMessage = postMessageMapper.selectById(messageLike.getMessageId());
            postMessage.setLikes(postMessage.getLikes() + 1);
            postMessageMapper.updateById(postMessage);

            map.put("error_message", "success");
            map.put("message", "点赞成功");
            return map;
        } else { // 说明这次是取消点赞
            messageLike.setStatus(0);
            messageLikeMapper.updateById(messageLike);

            PostMessage postMessage = postMessageMapper.selectById(messageLike.getMessageId());
            postMessage.setLikes(postMessage.getLikes() - 1);
            postMessageMapper.updateById(postMessage);

            map.put("error_message", "success");
            map.put("message", "取消点赞成功");
            return map;
        }
    }
}
