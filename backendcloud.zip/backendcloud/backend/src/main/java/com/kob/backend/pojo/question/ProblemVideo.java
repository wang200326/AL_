package com.kob.backend.pojo.question;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ProblemVideo {
    @TableId(type = IdType.AUTO)
    private Integer id;
    private Integer pbid;
    private String url;
    private String videoName;
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "Asia/Shanghai") // 选好时区 因为前端不会因为正确的时间而改变时区
    private Date createTime;
}
