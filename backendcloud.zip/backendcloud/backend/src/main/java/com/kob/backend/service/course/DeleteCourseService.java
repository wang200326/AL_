package com.kob.backend.service.course;

import java.util.Map;

public interface DeleteCourseService {
    public Map<String, String> deleteCourse(Map<String, String> data);
}
