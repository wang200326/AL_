package com.kob.backend.controller.pay;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.kob.backend.service.pay.ReadOneOrdersService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
public class ReadOneOrdersController {
    @Autowired
    private ReadOneOrdersService readOneOrdersService;
    @PostMapping("/orders/read/one/")
    public Map<String, String> readOneOrders() throws JsonProcessingException {
        return readOneOrdersService.readOneOrders();
    }
}
