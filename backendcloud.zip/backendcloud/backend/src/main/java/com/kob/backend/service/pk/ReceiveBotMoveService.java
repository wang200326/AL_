package com.kob.backend.service.pk;

public interface ReceiveBotMoveService {
    String receiveBoeMove(Integer userId, Integer direction);
}
