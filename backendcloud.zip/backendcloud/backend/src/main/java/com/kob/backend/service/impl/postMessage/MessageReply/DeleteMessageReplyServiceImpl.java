package com.kob.backend.service.impl.postMessage.MessageReply;

import com.kob.backend.mapper.postMessage.MessageReplyMapper;
import com.kob.backend.service.postMessage.MessageReply.DeleteMessageReplyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

@Service
public class DeleteMessageReplyServiceImpl implements DeleteMessageReplyService {
    @Autowired
    private MessageReplyMapper messageReplyMapper;
    @Override
    public Map<String, String> deleteMessageReply(Map<String, String> data) {
        Map<String, String> map = new HashMap<>();

        Integer id = Integer.valueOf(data.get("id"));

        messageReplyMapper.deleteById(id);

        map.put("error_message", "success");

        return map;
    }
}
