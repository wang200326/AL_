package com.kob.backend.controller.question;

import com.kob.backend.service.question.DeleteQuestionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
public class DeleteQuestionController {
    @Autowired
    private DeleteQuestionService deleteQuestionService;

    @PostMapping("/question/delete/")
    public Map<String, String> delete(@RequestParam Map<String, String> data) {
        return deleteQuestionService.delete(data);
    }
}
