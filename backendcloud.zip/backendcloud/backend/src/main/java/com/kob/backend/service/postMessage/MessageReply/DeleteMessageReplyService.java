package com.kob.backend.service.postMessage.MessageReply;

import java.util.Map;

public interface DeleteMessageReplyService {
    public Map<String, String> deleteMessageReply(Map<String, String> data);
}
