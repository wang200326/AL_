package com.kob.backend.service.compete.aboutCompete;

import java.util.Map;

public interface UpdateCompeteService {
    public Map<String, String> updateCompete(Map<String, String> data);
}
