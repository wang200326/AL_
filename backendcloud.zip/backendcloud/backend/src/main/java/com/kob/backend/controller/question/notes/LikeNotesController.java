package com.kob.backend.controller.question.notes;

import com.kob.backend.service.question.notes.LikeNotesService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
public class LikeNotesController {
    @Autowired
    private LikeNotesService likeNotesService;

    @PostMapping("/notes/like/")
    public Map<String, String> likeNotes(@RequestParam Map<String, String> data) {
        return likeNotesService.likeNotes(data);
    }
}
