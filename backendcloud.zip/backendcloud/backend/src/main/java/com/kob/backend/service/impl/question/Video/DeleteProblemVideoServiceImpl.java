package com.kob.backend.service.impl.question.Video;

import com.kob.backend.mapper.question.ProblemVideoMapper;
import com.kob.backend.service.question.Video.DeleteProblemVideoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

@Service
public class DeleteProblemVideoServiceImpl implements DeleteProblemVideoService {
    @Autowired
    private ProblemVideoMapper problemVideoMapper;

    @Override
    public Map<String, String> deleteProblemVideo(Map<String, String> data) {
        Map<String, String> map = new HashMap<>();

        String Id = data.get("id");
        if (Objects.equals(Id, "") || Id == null) {
            map.put("error_message", "id为空");
            return map;
        }
        Integer id = Integer.valueOf(Id);

        problemVideoMapper.deleteById(id);

        map.put("error_message", "success");
        return map;
    }
}
