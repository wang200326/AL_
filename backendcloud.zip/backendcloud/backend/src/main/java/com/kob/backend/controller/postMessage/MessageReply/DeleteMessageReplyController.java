package com.kob.backend.controller.postMessage.MessageReply;

import com.kob.backend.service.postMessage.MessageReply.DeleteMessageReplyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
public class DeleteMessageReplyController {
    @Autowired
    private DeleteMessageReplyService deleteMessageReplyService;
    @PostMapping("/messageReply/delete/")
    public Map<String, String> deleteMessageReply(@RequestParam Map<String, String> data) {
        return deleteMessageReplyService.deleteMessageReply(data);
    }
}
