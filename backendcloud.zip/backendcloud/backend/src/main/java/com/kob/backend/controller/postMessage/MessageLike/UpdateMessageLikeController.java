package com.kob.backend.controller.postMessage.MessageLike;

import com.kob.backend.service.postMessage.MessageLike.UpdateMessageLikeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
public class UpdateMessageLikeController {
    @Autowired
    private UpdateMessageLikeService updateMessageLikeService;
    @PostMapping("/message/like/update/")
    public Map<String, String> updateMessageLike(@RequestParam Map<String, String> data) {
        return updateMessageLikeService.updateMessageLike(data);
    }
}
