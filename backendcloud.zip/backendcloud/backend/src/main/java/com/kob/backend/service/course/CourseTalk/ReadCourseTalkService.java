package com.kob.backend.service.course.CourseTalk;

import com.fasterxml.jackson.core.JsonProcessingException;

import java.util.Map;

public interface ReadCourseTalkService {
    public Map<String, String> readCourseTalk(Map<String, String> data) throws JsonProcessingException;
}
