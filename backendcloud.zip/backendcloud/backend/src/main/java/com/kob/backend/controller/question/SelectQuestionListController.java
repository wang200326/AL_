package com.kob.backend.controller.question;


import com.kob.backend.service.question.SelectQuestionListService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Map;


@RestController
public class SelectQuestionListController {
    @Autowired
    private SelectQuestionListService selectQuestionListService;

    @GetMapping ("/select/question/")
    public Map<String, String> selectByAlTag(@RequestParam Map<String, String> data) {
        return selectQuestionListService.selectByAlTag(data);
    }
}
