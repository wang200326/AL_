package com.kob.backend.service.course.CatalogProblem;

import java.util.Map;

public interface UpdateCatalogProblemService {
    public Map<String, String> updateCatalogProblem(Map<String, String> data);
}
