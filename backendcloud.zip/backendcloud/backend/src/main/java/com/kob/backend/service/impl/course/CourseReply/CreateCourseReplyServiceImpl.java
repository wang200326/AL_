package com.kob.backend.service.impl.course.CourseReply;

import com.kob.backend.mapper.course.CourseReplyMapper;
import com.kob.backend.pojo.course.CourseReply;
import com.kob.backend.service.course.CourseReply.CreateCourseReplyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

@Service
public class CreateCourseReplyServiceImpl implements CreateCourseReplyService {
    @Autowired
    private CourseReplyMapper courseReplyMapper;
    @Override
    public Map<String, String> createCourseReply(Map<String, String> data) {
        Map<String, String> map = new HashMap<>();

        Integer user_id = Integer.valueOf(data.get("userId"));
        String user_name = data.get("userName");
        Integer other_id = Integer.valueOf(data.get("otherId"));
        String other_name = data.get("otherName");
        String photo = data.get("photo");
        String content = data.get("content");
        Integer card_id = Integer.valueOf(data.get("cardId"));

        if (content == "" || content == null) {
            map.put("error_message", "content为空");
            return map;
        } else if (content.length() > 1000) {
            map.put("error_message", "content长度超过1000");
            return map;
        }

        Date now = new Date();

        CourseReply courseReply = new CourseReply(
                null,
                user_id,
                user_name,
                other_id,
                other_name,
                photo,
                now,
                content,
                card_id
        );

        courseReplyMapper.insert(courseReply);

        map.put("error_message", "success");

        return map;
    }
}
