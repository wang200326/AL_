package com.kob.backend.service.question.notes;

import java.util.Map;

public interface GetLikeNotesService {
    public Map<String, String> getLike(Map<String, String> data);
}
