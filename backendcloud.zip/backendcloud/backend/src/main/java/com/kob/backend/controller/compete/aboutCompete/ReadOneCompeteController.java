package com.kob.backend.controller.compete.aboutCompete;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.kob.backend.service.compete.aboutCompete.ReadOneCompeteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
public class ReadOneCompeteController {
    @Autowired
    private ReadOneCompeteService readOneCompeteService;
    @PostMapping("/compete/read/one/")
    public Map<String, String> readOneCompete(@RequestParam Map<String,String> data) throws JsonProcessingException {
        return readOneCompeteService.readOneCompete(data);
    }
}
