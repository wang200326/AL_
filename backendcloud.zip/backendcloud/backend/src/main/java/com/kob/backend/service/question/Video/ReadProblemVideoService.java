package com.kob.backend.service.question.Video;

import com.fasterxml.jackson.core.JsonProcessingException;

import java.util.Map;

public interface ReadProblemVideoService {
    public Map<String, String> readProblemVideo(Map<String, String> data) throws JsonProcessingException;
}
