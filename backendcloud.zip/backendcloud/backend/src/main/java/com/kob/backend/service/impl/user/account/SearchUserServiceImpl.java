package com.kob.backend.service.impl.user.account;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.kob.backend.mapper.UserMapper;
import com.kob.backend.pojo.User;
import com.kob.backend.service.user.account.SearchUserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.websocket.server.ServerEndpoint;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class SearchUserServiceImpl implements SearchUserService {
    @Autowired
    private UserMapper userMapper;
    @Autowired
    private ObjectMapper objectMapper;
    @Override
    public Map<String, String> searchUser(Map<String, String> data) throws JsonProcessingException {
        Map<String, String> map = new HashMap<>();

        String name = data.get("name");

        QueryWrapper<User> queryWrapper = new QueryWrapper<>();
        queryWrapper.like("name", "%" + name + "%");

        List<User> list = userMapper.selectList(queryWrapper);

        if (list.isEmpty()) {
            map.put("error_message", "用户不存在");
            return map;
        }

        map.put("error_message", "success");
        map.put("list", objectMapper.writeValueAsString(list));
        return map;
    }
}
