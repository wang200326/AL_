package com.kob.backend.service.question;

import java.util.Map;

public interface SelectQuestionListService {
    public Map<String, String> selectByAlTag(Map<String, String> data);
}
