package com.kob.backend.service.impl.question.notes;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.kob.backend.mapper.question.NotesLikeMapper;
import com.kob.backend.mapper.question.NotesMapper;
import com.kob.backend.pojo.User;
import com.kob.backend.pojo.question.Notes;
import com.kob.backend.pojo.question.NotesLike;
import com.kob.backend.service.impl.utils.UserDetailsImpl;
import com.kob.backend.service.question.notes.GetLikeNotesService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

@Service
public class GetLikeNotesServiceImpl implements GetLikeNotesService {
    @Autowired
    private NotesLikeMapper notesLikeMapper;
    @Autowired
    private NotesMapper notesMapper;
    @Override
    public Map<String, String> getLike(Map<String, String> data) { // 传来userid和notesid
        Map<String, String> map = new HashMap<>();
        UsernamePasswordAuthenticationToken authentication =
                (UsernamePasswordAuthenticationToken) SecurityContextHolder.getContext().getAuthentication();

        UserDetailsImpl loginUser = (UserDetailsImpl) authentication.getPrincipal();
        User user = loginUser.getUser(); // 当前登录的用户

        Integer userid = Integer.valueOf(data.get("userid"));
        Integer notesid = Integer.valueOf(data.get("notesid"));

        Notes notes = notesMapper.selectById(notesid); // 找到对应题解行

        if (!userid.equals(user.getId())) {
            map.put("error_message", "用户id不一致");
            return map;
        }

        if (notes == null) {
            map.put("error_message", "题解不存在");
            return map;
        }

        QueryWrapper<NotesLike> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("notesid", notesid);
        queryWrapper.eq("userid", userid);
        NotesLike notesLike =  notesLikeMapper.selectOne(queryWrapper);

        if (notesLike == null) {
            map.put("error_message", "success");
            map.put("status", String.valueOf(0));
            return map;
        }

        System.err.println("notesLike" +  notesLike);
        map.put("error_message", "success");
        map.put("status", String.valueOf(notesLike.getStatus()));
        return map;
    }
}
