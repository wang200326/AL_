package com.kob.backend.service.postMessage.MessageLike;

import java.util.Map;

public interface CreateMessageLikeService {
    public Map<String, String> createMessageLike(Map<String, String> data);
}
