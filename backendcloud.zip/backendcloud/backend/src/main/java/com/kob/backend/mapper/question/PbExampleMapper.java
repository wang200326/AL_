package com.kob.backend.mapper.question;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.kob.backend.pojo.question.PbExample;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface PbExampleMapper extends BaseMapper<PbExample> {
}
