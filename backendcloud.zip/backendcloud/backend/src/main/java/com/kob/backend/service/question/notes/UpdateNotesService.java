package com.kob.backend.service.question.notes;

import java.util.Map;

public interface UpdateNotesService { // 修改题解捏
    public Map<String, String> updateNotes(Map<String, String> data);
}
