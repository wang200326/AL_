package com.kob.backend.service.course;

import com.fasterxml.jackson.core.JsonProcessingException;

import java.util.Map;

public interface ReadListCourseService {
    public Map<String, String> readListCourse() throws JsonProcessingException;
}
