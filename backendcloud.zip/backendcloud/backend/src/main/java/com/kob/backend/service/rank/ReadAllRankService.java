package com.kob.backend.service.rank;

import com.fasterxml.jackson.core.JsonProcessingException;

import java.util.Map;

public interface ReadAllRankService {
    public Map<String, String> readAllRank() throws JsonProcessingException;

}
