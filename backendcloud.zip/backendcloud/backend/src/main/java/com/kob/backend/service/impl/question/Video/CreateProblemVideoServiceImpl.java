package com.kob.backend.service.impl.question.Video;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.kob.backend.mapper.question.ProblemVideoMapper;
import com.kob.backend.mapper.question.QuestionMapper;
import com.kob.backend.pojo.question.ProblemVideo;
import com.kob.backend.pojo.question.Question;
import com.kob.backend.service.question.Video.CreateProblemVideoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

@Service
public class CreateProblemVideoServiceImpl implements CreateProblemVideoService {
    @Autowired
    private ProblemVideoMapper problemVideoMapper;
    @Autowired
    private QuestionMapper questionMapper;

    @Override
    public Map<String, String> createProblemVideo(Map<String, String> data) {
        Map<String, String> map = new HashMap<>();

        String Pbid = data.get("pbid");
        if (Objects.equals(Pbid, "") || Pbid == null) {
            map.put("error_message", "pbid不能为空");
            return map;
        }
        Integer pbid = Integer.valueOf(data.get("pbid"));
        String url = data.get("url");
        String video_name = data.get("videoName");

        if (pbid <= 0) {
            map.put("error_message", "pbid不能小于0");
            return map;
        }

        QueryWrapper<Question> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("pbid", pbid);
        if (questionMapper.selectOne(queryWrapper) == null) {
            map.put("error_message", "pbid对应的题目不存在");
            return map;
        }

        if (Objects.equals(url, "") || url == null) {
            map.put("error_message", "url为空");
            return map;
        } else if (url.length() > 100) {
            map.put("error_message", "url长度不能超过100字符");
            return map;
        }

        if (Objects.equals(video_name, "") || video_name == null) {
            map.put("error_message", "video_name为空");
            return map;
        } else if (video_name.length() > 100) {
            map.put("error_message", "video_name长度不能超过100字符");
            return map;
        }

        QueryWrapper<ProblemVideo> queryWrapper1 = new QueryWrapper<>();
        queryWrapper1.eq("pbid", pbid);
        if (problemVideoMapper.selectOne(queryWrapper1) != null) {
            UpdateWrapper<ProblemVideo> updateWrapper = new UpdateWrapper<>();
            updateWrapper.set("video_name", video_name);
            updateWrapper.set("url", "https://app6132.acapp.acwing.com.cn/media/" + url + "/stream.mpd");
            updateWrapper.eq("pbid", pbid);
            problemVideoMapper.update(null, updateWrapper);

            map.put("error_message", "success");

            return map;
        }

        Date now = new Date();
        ProblemVideo problemVideo = new ProblemVideo(
                null,
                pbid,
                "https://app6132.acapp.acwing.com.cn/media/" + url + "/stream.mpd",
                video_name,
                now
        );

        problemVideoMapper.insert(problemVideo);

        map.put("error_message", "success");
        return map;
    }
}
