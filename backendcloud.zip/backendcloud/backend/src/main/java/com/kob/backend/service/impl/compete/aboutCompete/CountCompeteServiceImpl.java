package com.kob.backend.service.impl.compete.aboutCompete;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.kob.backend.mapper.compete.CompeteMapper;
import com.kob.backend.pojo.compete.Compete;
import com.kob.backend.service.compete.aboutCompete.CountCompeteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class CountCompeteServiceImpl implements CountCompeteService {
    @Autowired
    private CompeteMapper competeMapper;
    @Autowired
    private ObjectMapper objectMapper;
    @Override
    public Map<String, String> countCompete() throws JsonProcessingException {
        Map<String, String> map = new HashMap<>();

        // 得到近三天 近一周 近一个月 近三个月的所有
        List<Compete> list = competeMapper.selectList(null);

        Date threeDaysAgo = getAgoTime(3);
        // 获取一周前的时间
        Date oneWeekAgo = getAgoTime(7);
        // 获取一个月前的时间
        Date oneMonthAgo = getAgoTime(30);
        // 获取三个月前的时间
        Date threeMonthsAgo = getAgoTime(90);



        List<Compete> list1 = new ArrayList<>();
        List<Compete> list2 = new ArrayList<>();
        List<Compete> list3 = new ArrayList<>();
        List<Compete> list4 = new ArrayList<>();

        for (Compete item : list) {
            if (item.getCloseTime().compareTo(threeDaysAgo) >= 0) { // 近三天的
                list1.add(item);
            }
            if (item.getCloseTime().compareTo(oneWeekAgo) >= 0) {
                list2.add(item);
            }
            if (item.getCloseTime().compareTo(oneMonthAgo) >= 0) {
                list3.add(item);
            }
            if (item.getCloseTime().compareTo(threeMonthsAgo) >= 0) {
                list4.add(item);
            }
        }

        String value1 = objectMapper.writeValueAsString(list1);
        String value2 = objectMapper.writeValueAsString(list2);
        String value3 = objectMapper.writeValueAsString(list3);
        String value4 = objectMapper.writeValueAsString(list4);

        map.put("error_message", "success");
        map.put("list1", value1);
        map.put("list2", value2);
        map.put("list3", value3);
        map.put("list4", value4);
        return map;
    }

    public static Date getAgoTime(int daysAgo) {
        // 获取中国时区
        TimeZone chinaTimeZone = TimeZone.getTimeZone("Asia/Shanghai");

        // 创建 Calendar 对象并设置时区
        Calendar calendar = Calendar.getInstance(chinaTimeZone);

        // 获取当前时间
        Date currentDate = new Date();

        // 设置当前时间到 Calendar 对象
        calendar.setTime(currentDate);

        // 计算指定天数前的时间
        calendar.add(Calendar.DAY_OF_MONTH, -daysAgo); // 根据传入的参数减去对应天数

        // 将时间设置为上午的0点（即上午零点）
        calendar.set(Calendar.HOUR_OF_DAY, 0);
        calendar.set(Calendar.MINUTE, 0);
        calendar.set(Calendar.SECOND, 0);
        calendar.set(Calendar.MILLISECOND, 0);

        // 获取指定天数前上午0点的时间
        return calendar.getTime();
    }
}
