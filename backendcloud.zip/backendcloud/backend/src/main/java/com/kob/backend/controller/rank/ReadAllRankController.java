package com.kob.backend.controller.rank;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.kob.backend.service.rank.ReadAllRankService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
public class ReadAllRankController {
    @Autowired
    private ReadAllRankService readAllRankService;
    @PostMapping("/rank/read/all/")
    public Map<String, String> readAllRank() throws JsonProcessingException {
        return readAllRankService.readAllRank();
    }

}
