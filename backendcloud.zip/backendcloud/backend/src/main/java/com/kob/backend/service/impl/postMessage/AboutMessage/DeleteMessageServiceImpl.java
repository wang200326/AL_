package com.kob.backend.service.impl.postMessage.AboutMessage;

import com.kob.backend.mapper.postMessage.PostMessageMapper;
import com.kob.backend.service.postMessage.AboutMessage.DeleteMessageService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

@Service
public class DeleteMessageServiceImpl implements DeleteMessageService {
    @Autowired
    private PostMessageMapper postMessageMapper;
    @Override
    public Map<String, String> deleteMessage(Map<String, String> data) {
        Map<String, String> map = new HashMap<>();

        Integer id = Integer.valueOf(data.get("id"));

        postMessageMapper.deleteById(id);

        map.put("error_message", "success");

        return map;
    }
}
