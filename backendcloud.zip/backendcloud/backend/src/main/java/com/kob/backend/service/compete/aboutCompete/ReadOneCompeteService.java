package com.kob.backend.service.compete.aboutCompete;

import com.fasterxml.jackson.core.JsonProcessingException;

import java.util.Map;

public interface ReadOneCompeteService {
    public Map<String, String> readOneCompete(Map<String, String> data) throws JsonProcessingException;
}
