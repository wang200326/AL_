package com.kob.backend.service.user.account;

import com.fasterxml.jackson.core.JsonProcessingException;

import java.util.Map;

public interface SearchUserService {
    public Map<String, String> searchUser(Map<String, String> data) throws JsonProcessingException;
}
