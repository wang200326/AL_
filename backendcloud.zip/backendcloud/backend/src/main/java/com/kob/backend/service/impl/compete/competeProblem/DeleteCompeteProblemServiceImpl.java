package com.kob.backend.service.impl.compete.competeProblem;

import com.kob.backend.mapper.compete.CompeteProblemMapper;
import com.kob.backend.service.compete.competeProblem.DeleteCompeteProblemService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

@Service
public class DeleteCompeteProblemServiceImpl implements DeleteCompeteProblemService {
    @Autowired
    private CompeteProblemMapper competeProblemMapper;
    @Override
    public Map<String, String> deleteCompeteProblem(Map<String, String> data) {
        Map<String, String> map = new HashMap<>();

        Integer id = Integer.valueOf(data.get("id"));

        competeProblemMapper.deleteById(id);

        map.put("error_message", "success");
        return map;
    }
}
