package com.kob.backend.service.course.Video;

import java.util.Map;

public interface UpdateCourseVideoService {
    public Map<String, String> updateVideo(Map<String, String> data);
}
