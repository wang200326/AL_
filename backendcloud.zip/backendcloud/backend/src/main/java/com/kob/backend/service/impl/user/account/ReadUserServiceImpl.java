package com.kob.backend.service.impl.user.account;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.kob.backend.mapper.UserMapper;
import com.kob.backend.service.user.account.ReadUserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

@Service
public class ReadUserServiceImpl implements ReadUserService {
    @Autowired
    private UserMapper userMapper;
    @Autowired
    private ObjectMapper objectMapper;
    @Override
    public Map<String, String> readUser() throws JsonProcessingException {
        Map<String, String> map = new HashMap<>();

        map.put("error_message", "success");
        map.put("list", objectMapper.writeValueAsString(userMapper.selectList(null)));

        return map;
    }
}
