package com.kob.backend.service.impl.compete.competeProblem;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.kob.backend.mapper.compete.CompeteProblemMapper;
import com.kob.backend.mapper.question.QuestionMapper;
import com.kob.backend.pojo.compete.CompeteProblem;
import com.kob.backend.pojo.question.Question;
import com.kob.backend.service.compete.competeProblem.CreateCompeteProblemService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

@Service
public class CreateCompeteProblemServiceImpl implements CreateCompeteProblemService {
    @Autowired
    private CompeteProblemMapper competeProblemMapper;
    @Autowired
    private QuestionMapper questionMapper;

    @Override
    public Map<String, String> createCompeteProblem(Map<String, String> data) {
        Map<String, String> map = new HashMap<>();

        String Pbid = data.get("pbid");
        Integer compete_id = Integer.valueOf(data.get("competeId"));
        String title = data.get("title");
        String number = data.get("number");

        if (Objects.equals(Pbid, "") || Pbid == null) {
            map.put("error_message", "pbid为空");
            return map;
        }

        Integer pbid = Integer.valueOf(Pbid);
        QueryWrapper<Question> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("pbid", pbid);

        if (pbid <= 0 || questionMapper.selectOne(queryWrapper) == null) {
            map.put("error_message", "pbid不合法或者对应题目不存在");
            return map;
        }

        if (Objects.equals(title, "") || title == null) {
            map.put("error_message", "title为空");
            return map;
        } else if (title.length() > 100) {
            map.put("error_message", "title长度不能超过100在字符");
            return map;
        }

        if (Objects.equals(number, "") || number == null) {
            map.put("error_message", "number为空");
            return map;
        } else if (number.length() > 100) {
            map.put("error_message", "number长度不能超过100在字符");
            return map;
        }

        CompeteProblem competeProblem = new CompeteProblem(
                null,
                pbid,
                compete_id,
                title,
                number
        );
        competeProblemMapper.insert(competeProblem);

        map.put("error_message", "success");
        return map;
    }
}
