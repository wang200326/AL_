package com.kob.backend.service.pay;

import com.fasterxml.jackson.core.JsonProcessingException;

import java.util.Map;

public interface ReadOrdersService {
    public Map<String, String> readOrders(Map<String, String> data) throws JsonProcessingException;
}
