package com.kob.backend.controller.course.Catalog;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.kob.backend.service.course.Catalog.ReadListCatalogService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.parameters.P;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
public class ReadListCatalogController {
    @Autowired
    private ReadListCatalogService readListCatalogService;

    @PostMapping("/catalog/read/list/")
    public Map<String, String> readListCatalog(@RequestParam Map<String, String> data) throws JsonProcessingException {
        return readListCatalogService.readListCatalog(data);
    }
}
