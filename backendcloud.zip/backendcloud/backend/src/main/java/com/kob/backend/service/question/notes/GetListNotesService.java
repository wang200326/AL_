package com.kob.backend.service.question.notes;

import com.fasterxml.jackson.core.JsonProcessingException;

import java.util.Map;

public interface GetListNotesService { // 获取对应题目的所有题解
    public Map<String, String> getListNotes(Map<String, String> data) throws JsonProcessingException;
}
