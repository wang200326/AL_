package com.kob.backend.controller.compete.aboutCompete;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.kob.backend.service.compete.aboutCompete.ReadCompeteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
public class ReadCompeteController {
    @Autowired
    private ReadCompeteService readCompeteService;

    @PostMapping("/compete/read/")
    public Map<String, String> readCompete() throws JsonProcessingException {
        return readCompeteService.readCompete();
    }
}
