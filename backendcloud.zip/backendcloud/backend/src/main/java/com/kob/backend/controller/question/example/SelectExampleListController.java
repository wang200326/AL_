package com.kob.backend.controller.question.example;

import com.kob.backend.service.question.example.SelectExampleListService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
public class SelectExampleListController {
    @Autowired
    private SelectExampleListService selectExampleListService;

    @PostMapping("/example/select/")
    public Map<String, String> get(@RequestParam Map<String, String> data) {
        return selectExampleListService.get(data);
    }
}
