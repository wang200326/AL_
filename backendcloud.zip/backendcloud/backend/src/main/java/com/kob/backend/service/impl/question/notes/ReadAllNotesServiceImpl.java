package com.kob.backend.service.impl.question.notes;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.kob.backend.mapper.question.NotesMapper;
import com.kob.backend.service.question.notes.ReadAllNotesService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

@Service
public class ReadAllNotesServiceImpl implements ReadAllNotesService {
    @Autowired
    private NotesMapper notesMapper;
    @Autowired
    private ObjectMapper objectMapper;
    @Override
    public Map<String, String> readAllNotes() throws JsonProcessingException {
        Map<String, String> map = new HashMap<>();


        map.put("error_message", "success");
        map.put("list", objectMapper.writeValueAsString(notesMapper.selectList(null)));
        return map;
    }
}
