package com.kob.backend.controller.compete.aboutCompete;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.kob.backend.service.compete.aboutCompete.SearchCompeteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
public class SearchCompeteController {
    @Autowired
    private SearchCompeteService searchCompeteService;
    @PostMapping("/compete/search/")
    public Map<String, String> searchCompete(@RequestParam Map<String, String> data) throws JsonProcessingException {
        return searchCompeteService.searchCompete(data);
    }
}
