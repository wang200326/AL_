package com.kob.backend.controller.postMessage.MessageReply;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.kob.backend.service.postMessage.MessageReply.ReadMessageReplyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
public class ReadMessageReplyController {
    @Autowired
    private ReadMessageReplyService readMessageReplyService;
    @PostMapping("/messageReply/read/")
    public Map<String, String> readMessageReply(@RequestParam Map<String, String> data) throws JsonProcessingException {
        return readMessageReplyService.readMessageReply(data);
    }
}
