package com.kob.backend.service.impl.course.Catalog;

import com.kob.backend.mapper.course.CatalogMapper;
import com.kob.backend.service.course.Catalog.DeleteCatalogService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

@Service
public class DeleteCatalogServiceImpl implements DeleteCatalogService {
    @Autowired
    private CatalogMapper catalogMapper;
    @Override
    public Map<String, String> deleteCatalog(Map<String, String> data){
        Map<String, String> map = new HashMap<>();

        Integer id = Integer.valueOf(data.get("id"));

        if (catalogMapper.selectById(id) == null) {
            map.put("error_message", "当前目录已经删除辣");
            return map;
        }

        catalogMapper.deleteById(id);



        map.put("error_message", "success");

        return map;
    }
}
