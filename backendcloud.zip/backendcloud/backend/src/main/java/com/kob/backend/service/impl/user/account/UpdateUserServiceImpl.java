package com.kob.backend.service.impl.user.account;

import com.kob.backend.mapper.UserMapper;
import com.kob.backend.pojo.User;
import com.kob.backend.service.impl.utils.UserDetailsImpl;
import com.kob.backend.service.user.account.UpdateUserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

@Service
public class UpdateUserServiceImpl implements UpdateUserService {
    @Autowired
    private UserMapper userMapper; // 待会查询需要用到
    @Override
    public Map<String, String> update(Map<String, String> data) { // data就是前端发来的信息
        UsernamePasswordAuthenticationToken authenticationToken =
                (UsernamePasswordAuthenticationToken) SecurityContextHolder.getContext().getAuthentication();
        UserDetailsImpl loginUser = (UserDetailsImpl) authenticationToken.getPrincipal();
        User user = loginUser.getUser(); // 得到用户表 这个就是当前用户

        // 取出要更改的数据 about photo name
        String about = data.get("about");
        String photo = data.get("photo");
        String name = data.get("name");

        // 开始进行各种限制判断
        Map<String, String> map = new HashMap<>();

        if (Objects.equals(name, "") || name.isEmpty()) name = user.getName();
        else if (name.length() > 100) { // 名字长度不能大于1000
            map.put("error_message", "名字长度不能大于100");
            return map;
        }

        if (Objects.equals(photo, "") || photo.isEmpty()) photo = user.getPhoto();
        else if (photo.length() > 1000) { // 头像链接长度不能大于1000
            map.put("error_message", "头像链接长度不能大于1000");
            return map;
        }

        if (Objects.equals(about, "") || about.isEmpty()) about = user.getAbout();
        else if (about.length() > 1000) { // 个人简介长度不能大于10000
            map.put("error_message", "个人简介长度不能大于10000");
            return map;
        }

        User NewUser = new User (
                user.getId(),
                user.getUsername(),
                user.getPassword(),
                photo,
                user.getRating(),
                name,
                about,
                user.getUserrank()
        );

        userMapper.updateById(NewUser);

        map.put("error_message", "success");
        return map;
    }
}
