package com.kob.backend.controller.course.CatalogProblem;

import com.kob.backend.service.course.CatalogProblem.UpdateCatalogProblemService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
public class UpdateCatalogProblemController {
    @Autowired
    private UpdateCatalogProblemService updateCatalogProblemService;

    @PostMapping("/catalogProblem/update/")
    public Map<String, String> updateCatalogProblem(@RequestParam Map<String, String> data) {
        return updateCatalogProblemService.updateCatalogProblem(data);
    }
}
