package com.kob.backend.component;

import com.alibaba.fastjson.JSONObject;
import com.kob.backend.component.utils.Jwt;
import com.kob.backend.mapper.Chat.friend_message.FriendMessageMapper;
import com.kob.backend.mapper.UserMapper;
import com.kob.backend.pojo.Chat.friend_message.FriendMessage;
import com.kob.backend.pojo.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.websocket.*;
import javax.websocket.server.PathParam;
import javax.websocket.server.ServerEndpoint;
import java.io.IOException;
import java.util.Objects;
import java.util.concurrent.ConcurrentHashMap;

@ServerEndpoint(value = "/chatSocket/{token}")
@Component
public class ChatSocket {
    // 要线程安全的 所有人都可见所以加static
    final private static ConcurrentHashMap<Integer, ChatSocket> users = new ConcurrentHashMap<>();
    private User user;
    private Session session = null; // 每个连接用session维护

    private static UserMapper userMapper;
    @Autowired
    public void setUserMapper(UserMapper userMapper) {
        ChatSocket.userMapper = userMapper;
    }

    private static FriendMessageMapper friendMessageMapper;
    @Autowired
    public void setUserMapper(FriendMessageMapper friendMessageMapper) {
        ChatSocket.friendMessageMapper = friendMessageMapper;
    }
    @OnOpen
    public void onOpen(Session session, @PathParam("token") String token) throws IOException {
        this.session = session;

        Integer userId = Jwt.getUserId(token);
//        System.err.println("userId = " + userId);
        this.user = userMapper.selectById(userId); // 根据用户id找对应的user

        if (this.user != null) {
//            System.err.println(user.getName() + "成功建立连接了");
            users.put(userId, this); // 加入用户池中
        } else {
            this.session.close();
        }
    }

    @OnClose
    public void onClose() {
//        System.err.println("disConnect");
        if (this.user != null) { // 到了这里说明断开了连接 并且我的user还不为空 说明我们并没有去除掉对应的user
            users.remove(this.user.getId());
//            System.err.println("已经删除user");
        }
    }

    @OnMessage
    public void onMessage(String message, Session session) { // 从前端接收信息 当作路由 判断一下是谁发来的消息 要发给谁
//        System.err.println("receive message");
        JSONObject data = JSONObject.parseObject(message); // 解析出message
        String msg = data.getString("event");

        if (Objects.equals(msg, "send_message")) {
//            System.err.println("content = " + data.getString("content"));
            TransMessage(Integer.valueOf(data.getString("otherId")), data.getString("otherPhoto"),
                    data.getString("content"));
        }

        // 先自己发自己收试试  首先要找到自己的session
        // 因为是自己和自己直接调用session就行了 但是未来是和别人聊天 那么就要从users里面找对应的session
    }

    @OnError
    public void onError(Session session, Throwable error) {
        error.printStackTrace();
    }

    private void TransMessage(Integer otherId, String otherPhoto, String message) {
        FriendMessage friendMessage = new FriendMessage(
                null,
                this.user.getId(),
                this.user.getPhoto(),
                otherId,
                otherPhoto,
                message
        );
        friendMessageMapper.insert(friendMessage);
        // 无论怎样 发出去的消息都会存起来
        if (users.get(otherId) != null) {
            JSONObject respA = new JSONObject();
            respA.put("event", "receive_message");
            respA.put("otherPhoto", otherPhoto);
            respA.put("otherId", otherId);
            respA.put("message", message);
            users.get(otherId).sendMessage(respA.toJSONString()); // 把消息发给otherId对应的人
        }
    }

    public void sendMessage(String message) { // 从后端向前端发送信息
        synchronized (this.session) {
            try {
                this.session.getBasicRemote().sendText(message);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
