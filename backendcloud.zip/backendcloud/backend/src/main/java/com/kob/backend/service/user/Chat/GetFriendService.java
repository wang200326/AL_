package com.kob.backend.service.user.Chat;

import java.util.Map;

public interface GetFriendService { // 返回好友
    public Map<String, String> getFriend(Map<String, String> data);
}
