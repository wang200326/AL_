package com.kob.backend.service.impl.question;

import com.kob.backend.mapper.question.QuestionMapper;
import com.kob.backend.service.question.DeleteQuestionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;
@Service
public class DeleteQuestionServiceImpl implements DeleteQuestionService {
    @Autowired
    private QuestionMapper questionMapper;

    @Override
    public Map<String, String> delete(Map<String, String> data) {
        // 前端只传id过来 后端通过id来删除 因为是已经存在的题目 所以不需要判断id存不存在之类的问题 直接删除就行了
        Integer id = Integer.valueOf(data.get("id"));
        questionMapper.deleteById(id);
        Map<String, String> map = new HashMap<>();

        map.put("error_message", "success");
        return map;
    }
}
