package com.kob.backend.service.impl.compete.aboutCompete;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.kob.backend.mapper.compete.CompeteMapper;
import com.kob.backend.pojo.compete.Compete;
import com.kob.backend.service.compete.aboutCompete.ReadCompeteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class ReadCompeteServiceImpl implements ReadCompeteService {
    @Autowired
    private CompeteMapper competeMapper;
    @Autowired
    private ObjectMapper objectMapper;

    @Override
    public Map<String, String> readCompete() throws JsonProcessingException {
        Map<String, String> map = new HashMap<>();

        QueryWrapper<Compete> queryWrapper = new QueryWrapper<>();
        queryWrapper.orderByDesc("start_time");
        List<Compete> list = competeMapper.selectList(queryWrapper);
        String value = objectMapper.writeValueAsString(list);

        map.put("error_message", "success");
        map.put("list", value);

        return map;
    }
}
