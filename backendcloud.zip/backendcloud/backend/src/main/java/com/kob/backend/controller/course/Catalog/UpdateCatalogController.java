package com.kob.backend.controller.course.Catalog;

import com.kob.backend.service.course.Catalog.UpdateCatalogService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
public class UpdateCatalogController {
    @Autowired
    private UpdateCatalogService updateCatalogService;

    @PostMapping("/catalog/update/")
    public Map<String, String> updateCatalog(@RequestParam Map<String, String> data) {
        return updateCatalogService.updateCatalog(data);
    }
}
