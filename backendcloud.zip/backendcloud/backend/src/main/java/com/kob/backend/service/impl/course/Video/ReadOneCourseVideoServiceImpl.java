package com.kob.backend.service.impl.course.Video;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.kob.backend.mapper.course.CourseVideoMapper;
import com.kob.backend.pojo.course.CourseVideo;
import com.kob.backend.service.course.Video.ReadOneCourseVideoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

@Service
public class ReadOneCourseVideoServiceImpl implements ReadOneCourseVideoService {
    @Autowired
    private CourseVideoMapper courseVideoMapper;
    @Autowired
    private ObjectMapper objectMapper;

    @Override
    public Map<String, String> readOneVideo(Map<String, String> data) throws JsonProcessingException {
        Map<String, String> map = new HashMap<>();

        String Id = data.get("id");
        if (Objects.equals(Id, "") || Id == null) {
            map.put("error_message", "id为空");
            return map;
        }

        Integer id = Integer.valueOf(Id);

        CourseVideo courseVideo =  courseVideoMapper.selectById(id);
        String value =  objectMapper.writeValueAsString(courseVideo);

        map.put("error_message", "success");
        map.put("courseVideo", value);
        return map;
    }
}
