package com.kob.backend.service.impl.postMessage.MessageLike;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.kob.backend.mapper.postMessage.MessageLikeMapper;
import com.kob.backend.pojo.postMessage.MessageLike;
import com.kob.backend.service.postMessage.MessageLike.ReadMessageLikeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

@Service
public class ReadMessageLikeServiceImpl implements ReadMessageLikeService {
    @Autowired
    private MessageLikeMapper messageLikeMapper;
    @Autowired
    private ObjectMapper objectMapper;
    @Override
    public Map<String, String> readMessageLike(Map<String, String> data) throws JsonProcessingException {
        Map<String, String> map = new HashMap<>();

        Integer message_id = Integer.valueOf(data.get("messageId"));
        Integer user_id = Integer.valueOf(data.get("userId"));

        QueryWrapper<MessageLike> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("message_id", message_id);
        queryWrapper.eq("user_id", user_id);

        MessageLike messageLike = messageLikeMapper.selectOne(queryWrapper);

        if (messageLike == null) {
            map.put("error_message", "还没点过赞捏");
            return map;
        }

        String value = objectMapper.writeValueAsString(messageLike);

        map.put("error_message", "success");
        map.put("value", value);
        return map;
    }
}
