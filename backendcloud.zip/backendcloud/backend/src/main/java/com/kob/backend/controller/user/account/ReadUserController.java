package com.kob.backend.controller.user.account;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.kob.backend.service.user.account.ReadUserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
public class ReadUserController {
    @Autowired
    private ReadUserService readUserService;
    @PostMapping("/user/read/")
    public Map<String, String> readUser() throws JsonProcessingException {
        return readUserService.readUser();
    }
}
