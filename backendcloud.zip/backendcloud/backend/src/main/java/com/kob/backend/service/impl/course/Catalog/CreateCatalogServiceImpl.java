package com.kob.backend.service.impl.course.Catalog;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.kob.backend.mapper.course.CatalogMapper;
import com.kob.backend.mapper.course.CourseMapper;
import com.kob.backend.pojo.course.Catalog;
import com.kob.backend.service.course.Catalog.CreateCatalogService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

@Service
public class CreateCatalogServiceImpl implements CreateCatalogService {
    @Autowired
    private CatalogMapper catalogMapper;
    @Autowired
    private CourseMapper courseMapper;

    @Override
    public Map<String, String> createCatalog(Map<String, String> data) {
        Map<String, String> map = new HashMap<>();

        Integer course_id = Integer.valueOf(data.get("courseId")); // 一般就不会改了
        String title = data.get("title");
        String content = data.get("content");
        Integer number = Integer.valueOf(data.get("number"));

        if (courseMapper.selectById(course_id) == null) {
            map.put("error_message", "course_id对应的课程不存在");
            return map;
        }

        if (Objects.equals(title, "") || title == null) {
            map.put("error_message", "title不能为空");
            return map;
        } else if (title.length() > 100) {
            map.put("error_message", "title不能大于100个字符");
            return map;
        }

        if (Objects.equals(content, "") || content == null) {
            map.put("error_message", "content不能为空");
            return map;
        } else if (content.length() > 1000) {
            map.put("error_message", "content不能大于100个字符");
            return map;
        }

        if (number <= 0) {
            map.put("error_message", "number不能小于0");
            return map;
        }

        QueryWrapper<Catalog> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("course_id", course_id);
        queryWrapper.eq("number", number);
        if (catalogMapper.selectOne(queryWrapper) != null) {
            map.put("error_message", "number已经存在了");
            return map;
        }

        Catalog catalog = new Catalog(
                null,
                course_id,
                title,
                content,
                number
        );
        catalogMapper.insert(catalog);

        map.put("error_message", "success");

        return map;
    }
}
