package com.kob.backend.service.course;

import com.fasterxml.jackson.core.JsonProcessingException;

import java.util.Map;

public interface ReadOneCourseService {
    public Map<String, String> readOneCourse(Map<String, String> data) throws JsonProcessingException;
}
