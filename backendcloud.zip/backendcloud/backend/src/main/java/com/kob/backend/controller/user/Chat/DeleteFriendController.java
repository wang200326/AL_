package com.kob.backend.controller.user.Chat;

import com.kob.backend.service.user.Chat.DeleteFriendService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
public class DeleteFriendController {
    @Autowired
    private DeleteFriendService deleteFriendService;

    @PostMapping("/friend/delete/")
    public Map<String, String> deleteFriend(@RequestParam Map<String, String> data) {
        return deleteFriendService.deleteFriend(data);
    }
}
