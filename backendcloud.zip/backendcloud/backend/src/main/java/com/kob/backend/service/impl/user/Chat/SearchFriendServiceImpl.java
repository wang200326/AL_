package com.kob.backend.service.impl.user.Chat;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.kob.backend.mapper.UserMapper;
import com.kob.backend.pojo.User;
import com.kob.backend.service.impl.user.util.UserObj;
import com.kob.backend.service.impl.utils.UserDetailsImpl;
import com.kob.backend.service.user.Chat.SearchFriendService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class SearchFriendServiceImpl implements SearchFriendService {
    @Autowired
    private UserMapper userMapper;
    @Autowired
    private ObjectMapper objectMapper;

    @Override
    public Map<String, String> searchFriend(Map<String, String> data) { // 搜索user 根据 name进行模糊查询
        UsernamePasswordAuthenticationToken authentication =
                (UsernamePasswordAuthenticationToken) SecurityContextHolder.getContext().getAuthentication();

        UserDetailsImpl loginUser = (UserDetailsImpl) authentication.getPrincipal();
        User user = loginUser.getUser(); // 当前登录的用户 我不能自己加自己鸭

        Map<String, String> map = new HashMap<>();
        String name = data.get("name"); // 获取前端传来的名字
        QueryWrapper<User> queryWrapper = new QueryWrapper<>(); // 写查询条件
        queryWrapper.like("name", name).and(i -> i.ne("id", user.getId()));

        List<User> lists = userMapper.selectList(queryWrapper); // 取到了所有符合条件的用户

        if (lists.isEmpty() || Objects.equals(name, "")) {
            map.put("error_message", "查不到信息所对应的用户捏");
            return map;
        }

        List<UserObj> list = new ArrayList<>(); // 这个是用来打包精简用户的

        for (User u : lists) {
            UserObj userObj = new UserObj();
            userObj.setId(u.getId());
            userObj.setName(u.getName());
            userObj.setPhoto(u.getPhoto());
            userObj.setUsername(u.getUsername());

            list.add(userObj);
        }

        String value = null;
        try {
            value = objectMapper.writeValueAsString(list);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
            // 处理异常
        }

        map.put("error_message", "success");
        map.put("list", value);
        return map;
    }
}
