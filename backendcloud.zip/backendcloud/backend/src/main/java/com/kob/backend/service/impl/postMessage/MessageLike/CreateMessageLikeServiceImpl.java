package com.kob.backend.service.impl.postMessage.MessageLike;

import com.kob.backend.mapper.postMessage.MessageLikeMapper;
import com.kob.backend.mapper.postMessage.PostMessageMapper;
import com.kob.backend.pojo.postMessage.MessageLike;
import com.kob.backend.pojo.postMessage.PostMessage;
import com.kob.backend.service.postMessage.MessageLike.CreateMessageLikeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

@Service
public class CreateMessageLikeServiceImpl implements CreateMessageLikeService {
    @Autowired
    private MessageLikeMapper messageLikeMapper;
    @Autowired
    private PostMessageMapper postMessageMapper;
    @Override
    public Map<String, String> createMessageLike(Map<String, String> data) {
        Map<String, String> map = new HashMap<>();

        Integer message_id = Integer.valueOf(data.get("messageId"));
        Integer user_id = Integer.valueOf(data.get("userId"));

        MessageLike messageLike = new MessageLike(
                null,
                message_id,
                1, // 表示点赞
                user_id
        );

        PostMessage postMessage = postMessageMapper.selectById(message_id);
        postMessage.setLikes(postMessage.getLikes() + 1);
        postMessageMapper.updateById(postMessage);

        messageLikeMapper.insert(messageLike);

        map.put("error_message", "success");
        return map;
    }
}
