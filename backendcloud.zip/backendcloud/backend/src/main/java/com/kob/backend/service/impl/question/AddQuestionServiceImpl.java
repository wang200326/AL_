package com.kob.backend.service.impl.question;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.kob.backend.mapper.question.QuestionMapper;
import com.kob.backend.pojo.question.Question;
import com.kob.backend.service.question.AddQuestionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

@Service
public class AddQuestionServiceImpl implements AddQuestionService {
    @Autowired
    private QuestionMapper questionMapper; // 取出题库表

    @Override
    public Map<String, String> add(Map<String, String> data) { // 实现增加一个题目
        // 这里不需要用户 直接加就行了
        Integer pbid = Integer.valueOf(data.get("pbid")); // 这个才是题号
        String name = data.get("name");
        String difficulty = data.get("difficulty"); // 难度
        String altag = data.get("altag"); // 算法标签
        String problemcontent = data.get("problemcontent"); // 题目描述
        String input = data.get("input"); // 这个是输入格式
        String output = data.get("output"); // 这个是输出格式
        String inexample = data.get("inexample"); // 这个是输入样例
        String outexample = data.get("outexample"); // 这个是输出样例
        String pbrange = data.get("range"); // 数据范围
        String tm = data.get("tm"); // 这个是时空复杂度
        String pbfrom = data.get("pbfrom"); // 这个是题目来源

        Map<String, String> map = new HashMap<>(); // 返回给前端的消息

        QueryWrapper<Question> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("pbid", pbid);
        List<Question> questions = questionMapper.selectList(queryWrapper);

        if (pbid <= 0) {
            map.put("error_message", "pbid不能小于等于0");
            return map;
        } else if (!questions.isEmpty()) {
            map.put("error_message", "当前的pbid已经存在");
            return map;
        }

        if (Objects.equals(name, "") || name.isEmpty()) {
            map.put("error_message", "名字不能为空");
            return map;
        } else if (name.length() > 100) {
            map.put("error_message", "名字长度不能超过100字符");
            return map;
        }

        if (Objects.equals(difficulty, "") || difficulty.isEmpty()) {
            map.put("error_message", "难度不能为空");
            return map;
        } else if (difficulty.length() > 10) {
            map.put("error_message", "难度长度不能超过10字符");
            return map;
        }

        if (Objects.equals(altag, "") || altag.isEmpty()) {
            map.put("error_message", "算法标签不能为空");
            return map;
        } else if (altag.length() > 500) {
            map.put("error_message", "难度长度不能超过500字符");
            return map;
        }

        if (Objects.equals(problemcontent, "") || problemcontent.isEmpty()) {
            map.put("error_message", "题目描述不能为空");
            return map;
        } else if (problemcontent.length() > 1000) {
            map.put("error_message", "题目描述的长度不能超过1000字符");
            return map;
        }

        if (Objects.equals(input, "") || input.isEmpty()) {
            map.put("error_message", "输入格式不能为空");
            return map;
        } else if (input.length() > 500) {
            map.put("error_message", "输入格式长度不能超过500字符");
            return map;
        }

        if (Objects.equals(output, "") || output.isEmpty()) {
            map.put("error_message", "输出格式不能为空");
            return map;
        } else if (output.length() > 500) {
            map.put("error_message", "输出格式长度不能超过500字符");
            return map;
        }

        if (Objects.equals(inexample, "") || inexample.isEmpty()) {
            map.put("error_message", "输入样例不能为空");
            return map;
        } else if (inexample.length() > 500) {
            map.put("error_message", "输入样例长度不能超过500字符");
            return map;
        }

        if (Objects.equals(outexample, "") || outexample.isEmpty()) {
            map.put("error_message", "输出样例不能为空");
            return map;
        } else if (outexample.length() > 500) {
            map.put("error_message", "输出样例长度不能超过500字符");
            return map;
        }

        if (Objects.equals(pbrange, "") || pbrange.isEmpty()) {
            map.put("error_message", "数据范围不能为空");
            return map;
        } else if (pbrange.length() > 100) {
            map.put("error_message", "数据范围长度不能超过100字符");
            return map;
        }

        if (Objects.equals(tm, "") || tm.isEmpty()) {
            map.put("error_message", "时空复杂度不能为空");
            return map;
        } else if (tm.length() > 100) {
            map.put("error_message", "时空复杂度长度不能超过100字符");
            return map;
        }

        if (Objects.equals(pbfrom, "") || pbfrom.isEmpty()) {
            map.put("error_message", "来源不能为空");
            return map;
        } else if (pbfrom.length() > 100) {
            map.put("error_message", "来源长度不能超过100字符");
            return map;
        }

        Question question = new Question(null, pbid, name, altag, problemcontent, difficulty, input, output, inexample, outexample, pbrange, tm, pbfrom);
        questionMapper.insert(question);

        map.put("error_message", "success"); // 说明成功了

        return map;
    }
}
