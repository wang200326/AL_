package com.kob.backend.service.compete.aboutCompete;

import com.fasterxml.jackson.core.JsonProcessingException;

import java.util.Map;

public interface ReadCompeteService {
    public Map<String, String> readCompete() throws JsonProcessingException;
}
