package com.kob.backend.controller.compete.competeRegister;

import com.kob.backend.service.compete.competeRegister.DeleteCompeteRegisterService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
public class DeleteCompeteRegisterController {
    @Autowired
    private DeleteCompeteRegisterService deleteCompeteRegisterService;
    @PostMapping("/competeRegister/delete/")
    public Map<String, String> deleteCompeteRegister(@RequestParam Map<String, String> data) {
        return deleteCompeteRegisterService.deleteCompeteRegister(data);
    }
}
