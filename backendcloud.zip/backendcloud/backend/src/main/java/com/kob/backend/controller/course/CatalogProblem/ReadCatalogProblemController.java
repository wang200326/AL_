package com.kob.backend.controller.course.CatalogProblem;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.kob.backend.service.course.CatalogProblem.ReadCatalogProblemService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
public class ReadCatalogProblemController {
    @Autowired
    private ReadCatalogProblemService readCatalogProblemService;

    @PostMapping("/catalogProblem/read/")
    public Map<String, String> readCatalogProblem(@RequestParam Map<String, String> data) throws JsonProcessingException {
        return readCatalogProblemService.ReadCatalogProblem(data);
    }
}
