package com.kob.backend.service.impl.course.Video;

import com.kob.backend.mapper.course.CourseVideoMapper;
import com.kob.backend.service.course.Video.DeleteCourseVideoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

@Service
public class DeleteCourseVideoServiceImpl implements DeleteCourseVideoService {
    @Autowired
    private CourseVideoMapper courseVideoMapper;

    @Override
    public Map<String, String> deleteVideo(Map<String, String> data) {
        Map<String, String> map = new HashMap<>();

        String Id = data.get("id");

        if (Objects.equals(Id, "") || Id == null) {
            map.put("error_message", "Id为空");
            return map;
        }

        Integer id = Integer.valueOf(Id);

        courseVideoMapper.deleteById(id);
        map.put("error_message", "success");
        return map;
    }
}
