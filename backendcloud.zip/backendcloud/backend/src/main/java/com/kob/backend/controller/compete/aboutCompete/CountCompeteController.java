package com.kob.backend.controller.compete.aboutCompete;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.kob.backend.service.compete.aboutCompete.CountCompeteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
public class CountCompeteController {
    @Autowired
    private CountCompeteService countCompeteService;
    @PostMapping("/compete/count/")
    public Map<String, String> countCompete() throws JsonProcessingException {
        return countCompeteService.countCompete();
    }
}
