package com.kob.backend.service.compete.aboutCompete;

import com.fasterxml.jackson.core.JsonProcessingException;

import java.util.Map;

public interface SelectCompeteService {
    public Map<String, String> selectCompete() throws JsonProcessingException; // 获取三种类型的竞赛 已经开始 未开始可以报名 已结束
}
