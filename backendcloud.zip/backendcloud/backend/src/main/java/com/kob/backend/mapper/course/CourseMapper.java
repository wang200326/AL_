package com.kob.backend.mapper.course;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.kob.backend.pojo.course.Course;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface CourseMapper extends BaseMapper<Course> {
}
