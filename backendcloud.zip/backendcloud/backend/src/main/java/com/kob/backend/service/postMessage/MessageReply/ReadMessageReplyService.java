package com.kob.backend.service.postMessage.MessageReply;

import com.fasterxml.jackson.core.JsonProcessingException;

import java.util.Map;

public interface ReadMessageReplyService {
    public Map<String, String> readMessageReply(Map<String, String> data) throws JsonProcessingException;
}
