package com.kob.backend.service.impl.course.CatalogProbem;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.kob.backend.mapper.course.CatalogProblemMapper;
import com.kob.backend.mapper.question.QuestionMapper;
import com.kob.backend.pojo.course.CatalogProblem;
import com.kob.backend.pojo.question.Question;
import com.kob.backend.service.course.CatalogProblem.CreateCatalogProblemService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

@Service
public class CreateCatalogProblemServiceImpl implements CreateCatalogProblemService {
    @Autowired
    private CatalogProblemMapper catalogProblemMapper;
    @Autowired
    private QuestionMapper questionMapper;

    @Override
    public Map<String, String> createCatalogProblem(Map<String, String> data) {
        Map<String, String> map = new HashMap<>();

        String pbId = data.get("pbid");
        String Catalog_id = data.get("catalogId");
        if (Objects.equals(pbId, "") || pbId == null) {
            map.put("error_message", "pbid不能为空");
            return map;
        }
        if (Objects.equals(Catalog_id, "") || Catalog_id == null) {
            map.put("error_message", "catalog_id不能为空");
            return map;
        }
        Integer pbid = Integer.valueOf(data.get("pbid"));
        String title = data.get("title");
        Integer catalog_id = Integer.valueOf(data.get("catalogId"));

        if (title == "" || title == null) {
            map.put("error_message", "title不能为空");
            return map;
        } else if (title.length() > 100) {
            map.put("error_message", "title不能超过100个字符");
            return map;
        }

        QueryWrapper<Question> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("pbid", pbid);
        Question question =  questionMapper.selectOne(queryWrapper);
        if (question == null) {
            map.put("error_message", "pbid对应的题目不存在");
            return map;
        }

        CatalogProblem catalogProblem = new CatalogProblem(
                null,
                pbid,
                question.getName(),
                title,
                catalog_id
        );

        catalogProblemMapper.insert(catalogProblem);
        map.put("error_message", "success");

        return map;
    }
}
