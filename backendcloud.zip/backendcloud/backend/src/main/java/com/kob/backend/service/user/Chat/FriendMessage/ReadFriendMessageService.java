package com.kob.backend.service.user.Chat.FriendMessage;

import com.fasterxml.jackson.core.JsonProcessingException;

import java.util.Map;

public interface ReadFriendMessageService {
    public Map<String, String> readFriendMessage(Map<String, String> data) throws JsonProcessingException;
}
