package com.kob.backend.controller.question.Video;

import com.kob.backend.service.question.Video.CreateProblemVideoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
public class CreateProblemVideoController {
    @Autowired
    private CreateProblemVideoService createProblemVideoService;

    @PostMapping("/problemVideo/create/")
    public Map<String, String> createProblemVideo(@RequestParam Map<String, String> data) {
        return createProblemVideoService.createProblemVideo(data);
    }
}
