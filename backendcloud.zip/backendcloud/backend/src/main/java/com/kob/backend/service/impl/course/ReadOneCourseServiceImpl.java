package com.kob.backend.service.impl.course;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.kob.backend.mapper.course.CourseMapper;
import com.kob.backend.pojo.course.Course;
import com.kob.backend.service.course.ReadOneCourseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

@Service
public class ReadOneCourseServiceImpl implements ReadOneCourseService {
    @Autowired
    private CourseMapper courseMapper;
    @Autowired
    private ObjectMapper objectMapper;

    @Override
    public Map<String, String> readOneCourse(Map<String, String> data) throws JsonProcessingException {
        Map<String, String> map = new HashMap<>();

        Integer id = Integer.valueOf(data.get("id"));
        QueryWrapper<Course> queryWrapper = new QueryWrapper<>();
//        queryWrapper.select("course_about", "words");
        queryWrapper.eq("id", id);
        Course course = courseMapper.selectOne(queryWrapper);

        if (course == null) {
            map.put("error_message", "id对应的课程不存在");
            return map;
        }

        String value = objectMapper.writeValueAsString(course);
        map.put("error_message", "success");
        map.put("course", value);
        return map;
    }
}
