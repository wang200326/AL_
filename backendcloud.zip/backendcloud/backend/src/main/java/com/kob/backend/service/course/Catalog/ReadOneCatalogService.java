package com.kob.backend.service.course.Catalog;

import java.util.Map;

public interface ReadOneCatalogService {
    public Map<String, String> readOne(Map<String, String> data);
}
