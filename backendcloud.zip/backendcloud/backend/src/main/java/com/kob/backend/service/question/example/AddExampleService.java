package com.kob.backend.service.question.example;

import java.util.Map;

public interface AddExampleService { // 这里是直接增加一个样例
    public Map<String, String> add(Map<String, String> data);
}
