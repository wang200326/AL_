package com.kob.backend.service.course;

import java.util.Map;

public interface UpdateCourseService {
    public Map<String, String> updateCourse(Map<String, String> data);
}
