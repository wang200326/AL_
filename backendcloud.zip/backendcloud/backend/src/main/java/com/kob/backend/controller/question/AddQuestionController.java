package com.kob.backend.controller.question;

import com.kob.backend.service.question.AddQuestionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
public class AddQuestionController{
    @Autowired
    private AddQuestionService addQuestionService;

    @PostMapping("/question/add/")
    public Map<String, String> add(@RequestParam Map<String, String> data) {
        System.out.println("我到添加题目这里了");
        return addQuestionService.add(data);
    }

}
