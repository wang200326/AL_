package com.kob.backend.service.impl.question.notes;

import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.kob.backend.mapper.question.NotesMapper;
import com.kob.backend.pojo.User;
import com.kob.backend.pojo.question.Notes;
import com.kob.backend.service.impl.utils.UserDetailsImpl;
import com.kob.backend.service.question.notes.UpdateNotesService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

@Service
public class UpdateNotesServiceImpl implements UpdateNotesService {
    @Autowired
    private NotesMapper notesMapper;
    @Override
    public Map<String, String> updateNotes(Map<String, String> data) {
        UsernamePasswordAuthenticationToken authentication =
                (UsernamePasswordAuthenticationToken) SecurityContextHolder.getContext().getAuthentication();

        UserDetailsImpl loginUser = (UserDetailsImpl) authentication.getPrincipal();
        User user = loginUser.getUser(); // 当前登录的用户
        Map<String, String> map = new HashMap<>();

        Integer id = Integer.valueOf(data.get("id"));
        String title = data.get("title");
        String markdown = data.get("markdown");
        String content = data.get("content");


        Notes notes = notesMapper.selectById(id);
        // 看看题解此时是否存在
        if (notes == null) {
            map.put("error_message", "题解不存在");
            return map;
        }

        if (!Objects.equals(notes.getUserid(), user.getId())) {
            map.put("error_message", "不可修改别人题解");
            return map;
        }

        if (markdown == null || markdown.isEmpty()) {
            map.put("error_message", "markdown不能为空或者null");
            return map;
        }
        else if (markdown.length() > 5000) {
            map.put("error_message", "markdown字符长度超过了5000");
            return map;
        }

        if (content == null || content.isEmpty()) {
            map.put("error_message", "content不能为空或者null");
            return map;
        }
        else if (content.length() > 100000) {
            map.put("error_message", "content字符长度超过了1000000");
            return map;
        }

        if (title == null || title.isEmpty()) {
            map.put("error_message", "title不能为空或者null");
            return map;
        }
        else if (title.length() > 100) {
            map.put("error_message", "title字符长度超过了100");
            return map;
        }

        UpdateWrapper<Notes> updateWrapper = new UpdateWrapper<>();
        updateWrapper.set("title", title);
        updateWrapper.set("markdown", markdown);
        updateWrapper.set("content", content);
        updateWrapper.eq("id", id);

        notesMapper.update(notes, updateWrapper);

        map.put("error_message", "success");

        return map;
    }
}
