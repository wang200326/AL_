package com.kob.backend.consumer.utils;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Player {
    private Integer id;
    private Integer botId; // -1表示人工操作蛇
    private String botCode;
    private Integer sx;
    private Integer sy;
    private List<Integer> steps; // 这个是存蛇走过的步

    private boolean check_tail_increasing(int step) { // 检查蛇什么时候会变长
        if (step <= 10) return true;
        return step % 3 == 1; //  > 10步之后 每三步增加一点长度
    }
    public List<Cell> getCells() {
        List<Cell> res = new ArrayList<>();

        int [] dx = {-1, 0, 1, 0}, dy = {0, 1, 0, -1};
        int x = sx , y = sy;
        int step = 0;
        res.add(new Cell(x, y));
        for (int d : steps) { // 直接取出下一步的方向
            x += dx[d];
            y += dy[d];
            res.add(new Cell(x, y));
            if (!check_tail_increasing( ++ step)) {
                res.remove(0); // 如果这一步不需要加长身体 那么就删掉蛇尾
            }
        }
        return res;
    }

    public String getStepsString() {
        StringBuilder res = new StringBuilder();
        for (int d : steps) {
            res.append(d);
        }
        return res.toString();
    }
}
