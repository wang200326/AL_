package com.kob.backend.service.impl.user.bot;

import com.kob.backend.mapper.BotMapper;
import com.kob.backend.pojo.Bot;
import com.kob.backend.pojo.User;
import com.kob.backend.service.impl.utils.UserDetailsImpl;
import com.kob.backend.service.user.bot.AddService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

@Service
public class AddServiceImpl implements AddService {

    @Autowired
    private BotMapper botMapper;

    @Override
    public Map<String, String> add(Map<String, String> data) {
        UsernamePasswordAuthenticationToken authenticationToken =
                (UsernamePasswordAuthenticationToken) SecurityContextHolder.getContext().getAuthentication();
        UserDetailsImpl loginUser = (UserDetailsImpl) authenticationToken.getPrincipal();
        User user = loginUser.getUser(); // 得到用户表

        String title = data.get("title"); // bot名字
        String description = data.get("description"); // bot描述
        String content = data.get("content"); // bot的代码

        Map<String, String> map = new HashMap<>();

        if (title == null || title.isEmpty()) { // 保证bot名字不能为空
            map.put("error_message", "bot名字不能为空");
            return map;
        }
        else if (title.length() > 100) { // 保证bot名字不能超过100个字符
            map.put("error_message", "bot名字不能超过100个字符");
            return map;
        }

        if (description == null || description.isEmpty()) {
            description = "这个用户很懒，什么也没留下捏~";
        }  //Bot描述可以为空
        else if (description.length() > 300) { // 保证bot描述不能超过300个字符
            map.put("error_message", "bot描述不能超过300个字符");
        }

        if (content == null || content.isEmpty()) { // 保证bot代码不能为空
            map.put("error_message", "代码不能为空");
            return map;
        }
        else if (content.length() > 10000) {
            map.put("error_message", "bot代码不能超过10000个字符");
            return map;
        }

        Date now = new Date(); // 返回当前时间
        Bot bot = new Bot(null, user.getId(), title, description, content, now, now);

        botMapper.insert(bot); // 把新bot插入库中
        map.put("error_message", "success");

        return map;
    }
}
