package com.kob.backend.service.impl.compete.competeProblem;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.kob.backend.mapper.compete.CompeteProblemMapper;
import com.kob.backend.pojo.compete.CompeteProblem;
import com.kob.backend.service.compete.competeProblem.ReadCompeteProblemService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class ReadCompeteProblemServiceImpl implements ReadCompeteProblemService {
    @Autowired
    private CompeteProblemMapper competeProblemMapper;
    @Autowired
    private ObjectMapper objectMapper;
    @Override
    public Map<String, String> readCompeteProblem(Map<String, String> data) throws JsonProcessingException {
        Map<String,String> map = new HashMap<>();

        Integer compete_id = Integer.valueOf(data.get("competeId"));

        QueryWrapper<CompeteProblem> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("compete_id", compete_id);
        queryWrapper.orderByAsc("number");
        List<CompeteProblem> list =  competeProblemMapper.selectList(queryWrapper);

        if (list.isEmpty()) {
            map.put("error_message", "没有试题");
            return map;
        }

        String value = objectMapper.writeValueAsString(list);
        map.put("error_message", "success");
        map.put("list", value);

        return map;
    }
}
