package com.kob.backend.service.impl.question.example;

import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.kob.backend.mapper.question.PbExampleMapper;
import com.kob.backend.pojo.question.PbExample;
import com.kob.backend.service.question.example.SelectExampleListService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

@Service
public class SelectExampleListServiceImpl implements SelectExampleListService {
    @Autowired
    private PbExampleMapper pbExampleMapper;

    @Override
    public Map<String, String> get(Map<String, String> data) { // 获取的话 就根据pbid来找
        Integer pbid = Integer.valueOf(data.get("pbid"));
        QueryWrapper<PbExample> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("pbid", pbid);
        ObjectMapper objectMapper = new ObjectMapper();

        String List = null;

        try {
            List = objectMapper.writeValueAsString(pbExampleMapper.selectList(queryWrapper));
        } catch (JsonProcessingException e) {
            e.printStackTrace();
            // 处理异常
        }

        Map<String, String> map = new HashMap<>();

        map.put("error_message", "success");
        map.put("List", List);

        return map;
    }
}
