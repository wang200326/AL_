package com.kob.backend.mapper.Chat.friend_message;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.kob.backend.pojo.Chat.friend_message.FriendMessage;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface FriendMessageMapper extends BaseMapper<FriendMessage> {
}
