package com.kob.backend.mapper.course;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.kob.backend.pojo.course.CatalogProblem;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface CatalogProblemMapper extends BaseMapper<CatalogProblem> {
}
