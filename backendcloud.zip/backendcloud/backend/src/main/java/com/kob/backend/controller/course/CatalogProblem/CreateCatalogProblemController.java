package com.kob.backend.controller.course.CatalogProblem;

import com.kob.backend.service.course.CatalogProblem.CreateCatalogProblemService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
public class CreateCatalogProblemController {
    @Autowired
    private CreateCatalogProblemService createCatalogProblemService;

    @PostMapping("/catalogProblem/create/")
    public Map<String, String> createCatalogProblem(@RequestParam Map<String, String> data) {
        return createCatalogProblemService.createCatalogProblem(data);
    }
}
