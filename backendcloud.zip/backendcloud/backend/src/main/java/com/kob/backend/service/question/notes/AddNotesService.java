package com.kob.backend.service.question.notes;

import java.util.Map;

public interface AddNotesService { // 新加一个题解
    public Map<String, String> addNotes(Map<String, String> data);
}
