package com.kob.backend.service.impl.pay;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.kob.backend.mapper.Order.OrdersMapper;
import com.kob.backend.pojo.Order.Orders;
import com.kob.backend.pojo.User;
import com.kob.backend.service.impl.utils.UserDetailsImpl;
import com.kob.backend.service.pay.ReadOneOrdersService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class ReadOneOrdersServiceImpl implements ReadOneOrdersService {
    @Autowired
    private OrdersMapper ordersMapper;
    @Autowired
    private ObjectMapper objectMapper;

    @Override
    public Map<String, String> readOneOrders() throws JsonProcessingException {
        Map<String, String> map = new HashMap<>();

        UsernamePasswordAuthenticationToken authentication =
                (UsernamePasswordAuthenticationToken) SecurityContextHolder.getContext().getAuthentication();

        UserDetailsImpl loginUser = (UserDetailsImpl) authentication.getPrincipal();
        User user = loginUser.getUser();

        QueryWrapper<Orders> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("user_id", user.getId());
        List<Orders> list =  ordersMapper.selectList(queryWrapper);

        if (list.isEmpty()) {
            map.put("error_message", "暂未购买课程");
            return map;
        }

        map.put("error_message", "success");
        map.put("list", objectMapper.writeValueAsString(list));

        return map;
    }
}
