package com.kob.backend.service.course;

import java.util.Map;

public interface CreateCourseService {
    public Map<String, String> createCourse(Map<String, String> data);
}
