package com.kob.backend.service.question.notes;

import com.fasterxml.jackson.core.JsonProcessingException;

import java.util.Map;

public interface ReadAllNotesService {
    public Map<String, String> readAllNotes() throws JsonProcessingException;
}
