package com.kob.backend.controller.user.Chat;

import com.kob.backend.service.user.Chat.GetFriendService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
public class GetFriendController {
    @Autowired
    private GetFriendService getFriendService;

    @PostMapping("/friend/get/")
    public Map<String, String> getFriend(@RequestParam Map<String, String> data) {
        return getFriendService.getFriend(data);
    }
}
