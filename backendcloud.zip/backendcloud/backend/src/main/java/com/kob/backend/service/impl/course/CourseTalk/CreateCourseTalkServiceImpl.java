package com.kob.backend.service.impl.course.CourseTalk;

import com.kob.backend.mapper.course.CourseTalkMapper;
import com.kob.backend.pojo.course.CourseTalk;
import com.kob.backend.service.course.CourseTalk.CreateCourseTalkService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

@Service
public class CreateCourseTalkServiceImpl implements CreateCourseTalkService {
    @Autowired
    private CourseTalkMapper courseTalkMapper;
    @Override
    public Map<String, String> createCourseTalk(Map<String, String> data) {
        Map<String, String> map = new HashMap<>();

        Integer course_id = Integer.valueOf(data.get("courseId"));
        Integer user_id = Integer.valueOf(data.get("userId"));
        String user_name = data.get("userName");
        String content = data.get("content");
        String markdown = data.get("markdown");
        String photo = data.get("photo");

        if (Objects.equals(content, "") || content == null) {
            map.put("error_message", "content为空");
            return map;
        } else if (content.length() > 8000000) {
            map.put("error_message", "content长度超过了8000000字符");
            return map;
        }

        if (Objects.equals(markdown, "") || markdown == null) {
            map.put("error_message", "markdown为空");
            return map;
        } else if (markdown.length() > 10000) {
            map.put("error_message", "markdown长度超过了10000字符");
            return map;
        }

        if (Objects.equals(photo, "") || photo == null) {
            map.put("error_message", "photo为空");
            return map;
        } else if (photo.length() > 100) {
            map.put("error_message", "photo长度超过了100字符");
            return map;
        }

        Date now = new Date();

        CourseTalk courseTalk = new CourseTalk(
                null,
                user_id,
                user_name,
                content,
                now,
                course_id,
                markdown,
                photo
        );

        courseTalkMapper.insert(courseTalk);

        map.put("error_message", "success");
        return map;
    }
}
