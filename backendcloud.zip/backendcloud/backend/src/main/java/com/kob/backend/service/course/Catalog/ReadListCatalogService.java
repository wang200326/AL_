package com.kob.backend.service.course.Catalog;

import com.fasterxml.jackson.core.JsonProcessingException;

import java.util.Map;

public interface ReadListCatalogService {
    public Map<String, String> readListCatalog(Map<String, String> data) throws JsonProcessingException;
}
