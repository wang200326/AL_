package com.kob.backend.service.compete.competeRegister;

import java.util.Map;

public interface CreateCompeteRegisterService {
    public Map<String, String> createCompeteRegister(Map<String, String> data);
}
