package com.kob.backend.controller.course;

import com.kob.backend.service.course.CreateCourseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
public class CreateCourseController {
    @Autowired
    private CreateCourseService createCourseService;

    @PostMapping("/course/create/")
    public Map<String, String> createCourse(@RequestParam Map<String, String> data) {
        return createCourseService.createCourse(data);
    }
}
