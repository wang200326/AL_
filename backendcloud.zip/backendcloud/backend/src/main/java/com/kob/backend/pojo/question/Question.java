package com.kob.backend.pojo.question;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Question { // 题库表
    @TableId(type = IdType.AUTO)
    private Integer id;
    private Integer pbid;
    private String name;
    private String altag;
    private String problemcontent;
    private String difficulty;
    private String input;
    private String output;
    private String inexample;
    private String outexample;
    private String pbrange;
    private String tm;
    private String pbfrom;
//    private String markdown;
//    private String content;
}
