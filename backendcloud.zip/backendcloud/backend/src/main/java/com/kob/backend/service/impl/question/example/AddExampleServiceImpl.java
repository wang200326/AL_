package com.kob.backend.service.impl.question.example;

import com.kob.backend.mapper.question.PbExampleMapper;
import com.kob.backend.pojo.question.PbExample;
import com.kob.backend.service.question.example.AddExampleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

@Service
public class AddExampleServiceImpl implements AddExampleService {
    @Autowired
    private PbExampleMapper pbExampleMapper;

    @Override
    public Map<String, String> add(Map<String, String> data) {
        Integer pbid = Integer.valueOf(data.get("pbid"));
        String inexample = data.get("inexample");
        String outexample = data.get("outexample");

        Map<String, String> map = new HashMap<>();
        // 首先pbid一定是存在的，因为我前端传就是靠pbid进入页面的

        if (Objects.equals(inexample, "") || inexample.isEmpty()) {
            map.put("error_message", "输入样例不能为空");
            return map;
        } else if (inexample.length() > 5000) {
            map.put("error_message", "输入样例不能超过5000");
            return map;
        }

        if (Objects.equals(outexample, "") || outexample.isEmpty()) {
            map.put("error_message", "输出样例不能为空");
            return map;
        } else if (outexample.length() > 5000) {
            map.put("error_message", "输出样例不能超过5000");
            return map;
        }

        PbExample pbExample = new PbExample(null, pbid, inexample, outexample);
        pbExampleMapper.insert(pbExample);
        
        map.put("error_message", "success");
        return map;
    }
}
