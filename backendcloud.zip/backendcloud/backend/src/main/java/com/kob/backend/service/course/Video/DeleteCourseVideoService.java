package com.kob.backend.service.course.Video;

import java.util.Map;

public interface DeleteCourseVideoService {
    public Map<String, String> deleteVideo(Map<String, String> data);
}
