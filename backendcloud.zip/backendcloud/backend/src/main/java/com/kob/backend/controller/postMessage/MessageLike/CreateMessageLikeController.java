package com.kob.backend.controller.postMessage.MessageLike;

import com.kob.backend.service.postMessage.MessageLike.CreateMessageLikeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
public class CreateMessageLikeController {
    @Autowired
    private CreateMessageLikeService createMessageLikeService;
    @PostMapping("/message/like/create/")
    public Map<String, String> createMessageLike(@RequestParam Map<String, String> data) {
        return createMessageLikeService.createMessageLike(data);
    }
}
