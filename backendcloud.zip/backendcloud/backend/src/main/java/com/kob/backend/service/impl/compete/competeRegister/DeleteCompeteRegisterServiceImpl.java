package com.kob.backend.service.impl.compete.competeRegister;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.kob.backend.mapper.compete.CompeteMapper;
import com.kob.backend.mapper.compete.CompeteRegisterMapper;
import com.kob.backend.pojo.compete.Compete;
import com.kob.backend.pojo.compete.CompeteRegister;
import com.kob.backend.service.compete.competeRegister.DeleteCompeteRegisterService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

@Service
public class DeleteCompeteRegisterServiceImpl implements DeleteCompeteRegisterService {
    @Autowired
    private CompeteRegisterMapper competeRegisterMapper;
    @Autowired
    private CompeteMapper competeMapper;
    @Override
    public Map<String, String> deleteCompeteRegister(Map<String, String> data) {
        Map<String, String> map = new HashMap<>();

        Integer id = Integer.valueOf(data.get("id"));

        CompeteRegister competeRegister = competeRegisterMapper.selectById(id);

        if (competeRegister == null) {
            map.put("error_message", "已成功取消报名");
            return map;
        }
        competeRegisterMapper.deleteById(id);

        Compete compete = competeMapper.selectById(competeRegister.getCompeteId());
        compete.setParticipant(compete.getParticipant() - 1);
        competeMapper.updateById(compete);


        map.put("error_message", "success");
        return map;
    }
}
