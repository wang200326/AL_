package com.kob.backend.service.postMessage.AboutMessage;

import java.util.Map;

public interface CreateMessageService {
    public Map<String, String> createMessage(Map<String, String> data);
}
