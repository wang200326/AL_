package com.kob.backend.controller.question.notes;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.kob.backend.service.question.notes.ReadAllNotesService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
public class ReadAllNotesController {
    @Autowired
    private ReadAllNotesService readAllNotesService;
    @PostMapping("/notes/read/all/")
    public Map<String, String> readAllNotes() throws JsonProcessingException {
        return readAllNotesService.readAllNotes();
    }
}
