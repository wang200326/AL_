package com.kob.backend.controller.compete.competeRegister;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.kob.backend.service.compete.competeRegister.ReadCompeteRegisterService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
public class ReadCompeteRegisterController {
    @Autowired
    private ReadCompeteRegisterService readCompeteRegisterService;
    @PostMapping("/competeRegister/read/")
    public Map<String, String> readCompeteRegister(@RequestParam Map<String, String> data) throws JsonProcessingException {
        return readCompeteRegisterService.readCompeteRegister(data);
    }
}
