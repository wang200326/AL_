package com.kob.backend.service.course.CatalogProblem;

import java.util.Map;

public interface CreateCatalogProblemService {
    public Map<String, String> createCatalogProblem(Map<String, String> data);
}
