package com.kob.backend.service.course.Catalog;

import java.util.Map;

public interface UpdateCatalogService {
    public Map<String, String> updateCatalog(Map<String, String> data);
}
