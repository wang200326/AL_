package com.kob.backend.controller.question.notes;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.kob.backend.service.question.notes.GetListNotesService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
public class GetListNotesController {
    @Autowired
    private GetListNotesService getListNotesService;

    @PostMapping("/notes/getlist/")
    public Map<String, String> getNotes(@RequestParam Map<String, String> data) throws JsonProcessingException {
        return getListNotesService.getListNotes(data);
    }
}
