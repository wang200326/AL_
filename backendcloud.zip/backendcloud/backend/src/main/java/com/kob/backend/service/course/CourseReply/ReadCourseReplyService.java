package com.kob.backend.service.course.CourseReply;

import com.fasterxml.jackson.core.JsonProcessingException;

import java.util.Map;

public interface ReadCourseReplyService {
    public Map<String, String> readCourseReply(Map<String, String> data) throws JsonProcessingException;
}
