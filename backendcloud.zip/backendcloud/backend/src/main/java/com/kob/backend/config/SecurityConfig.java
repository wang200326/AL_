package com.kob.backend.config;

import com.kob.backend.config.filter.JwtAuthenticationTokenFilter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

@Configuration
@EnableWebSecurity
public class SecurityConfig extends WebSecurityConfigurerAdapter {
    @Autowired
    private JwtAuthenticationTokenFilter jwtAuthenticationTokenFilter;

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Bean
    @Override
    public AuthenticationManager authenticationManagerBean() throws Exception {
        return super.authenticationManagerBean();
    }

    @Override
    protected void configure(HttpSecurity http) throws Exception {
        http.csrf().disable()
                .sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS)
                .and()
                .authorizeRequests()
                .antMatchers("/user/account/token/", "/user/account/register/", // 登录注册放行路径
                        "/select/question/", "/question/get/", "/question/get/one/", "/example/select/", // 题库放行路径
                        "/notes/getlist/", "/notes/getone/", "/notes/read/all/", // 题解放行路径
                        "/course/read/list/", "/course/read/one/", // 课程放行路径
                        "/catalog/read/list/", // 课程目录放行路径
                        "/catalogProblem/read/", // 课程习题放行路径
                        "/compete/read/", "/compete/select/", "/compete/read/one/", // 竞赛放行路径
                        "/competeProblem/read/", // 竞赛试题放行路径
                        "/rank/read/all/", // 排名放行路径
                        "/messageReply/read/", "/postMessage/read/", // 讨论区放行路径
                        "/alipay/pay", "/alipay/notify", "/ordersSalary/read/", // 支付宝支付放行路径
                        "/user/read/", "/orders/read/one/").permitAll() // 管理用户放行路径
                .antMatchers("/pk/start/game/", "/pk/receive/bot/move/").hasIpAddress("127.0.0.1")
                .antMatchers(HttpMethod.OPTIONS).permitAll()
                .anyRequest().authenticated();

        http.addFilterBefore(jwtAuthenticationTokenFilter, UsernamePasswordAuthenticationFilter.class);
    }

    // 放行WebSocket
    @Override
    public void configure(WebSecurity web) throws Exception {
        web.ignoring().antMatchers("/websocket/**", "/chatSocket/**");
    }
}