package com.kob.backend.service.course.Video;

import java.util.Map;

public interface CreateCourseVideoService {
    public Map<String, String> createVideo(Map<String, String> data);
}
