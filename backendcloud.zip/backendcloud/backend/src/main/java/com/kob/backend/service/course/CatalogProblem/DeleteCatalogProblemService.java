package com.kob.backend.service.course.CatalogProblem;

import java.util.Map;

public interface DeleteCatalogProblemService {
    public Map<String, String> deleteCatalogProblem(Map<String, String> data);
}
