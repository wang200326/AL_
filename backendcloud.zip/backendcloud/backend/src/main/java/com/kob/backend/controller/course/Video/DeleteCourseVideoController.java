package com.kob.backend.controller.course.Video;

import com.kob.backend.service.course.Video.DeleteCourseVideoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
public class DeleteCourseVideoController {
    @Autowired
    private DeleteCourseVideoService deleteCourseVideoService;

    @PostMapping("/courseVideo/delete/")
    public Map<String, String> deleteCourseVideo(@RequestParam Map<String, String> data) {
        return deleteCourseVideoService.deleteVideo(data);
    }
}
