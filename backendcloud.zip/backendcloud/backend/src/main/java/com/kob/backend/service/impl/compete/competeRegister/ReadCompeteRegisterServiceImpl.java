package com.kob.backend.service.impl.compete.competeRegister;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.kob.backend.mapper.compete.CompeteRegisterMapper;
import com.kob.backend.pojo.compete.CompeteRegister;
import com.kob.backend.service.compete.competeRegister.ReadCompeteRegisterService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

@Service
public class ReadCompeteRegisterServiceImpl implements ReadCompeteRegisterService {
    @Autowired
    private CompeteRegisterMapper competeRegisterMapper;
    @Autowired
    private ObjectMapper objectMapper;
    @Override
    public Map<String, String> readCompeteRegister(Map<String, String> data) throws JsonProcessingException {
        Map<String, String> map = new HashMap<>();

        Integer userId = Integer.valueOf(data.get("userId"));
        Integer competeId = Integer.valueOf(data.get("competeId"));

        QueryWrapper<CompeteRegister> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("user_id", userId);
        queryWrapper.eq("compete_id", competeId);

        CompeteRegister competeRegister = competeRegisterMapper.selectOne(queryWrapper);

        if (competeRegister == null) {
            map.put("error_message", "未报名该竞赛");
            return map;
        }

        String value = objectMapper.writeValueAsString(competeRegister);

        map.put("error_message", "success");
        map.put("value", value);
        return map;
    }
}
