package com.kob.backend.controller.question.example;

import com.kob.backend.service.question.example.AddExampleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
public class AddExampleController {
    @Autowired
    private AddExampleService addExampleService;

    @PostMapping("/example/add/")
    public Map<String, String> add(@RequestParam Map<String, String> data) {
        return addExampleService.add(data);
    }
}
