package com.kob.backend.service.impl.compete.competeRegister;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.kob.backend.mapper.compete.CompeteMapper;
import com.kob.backend.mapper.compete.CompeteRegisterMapper;
import com.kob.backend.pojo.compete.Compete;
import com.kob.backend.pojo.compete.CompeteRegister;
import com.kob.backend.service.compete.competeRegister.CreateCompeteRegisterService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

@Service
public class CreateCompeteRegisterServiceImpl implements CreateCompeteRegisterService {
    @Autowired
    private CompeteRegisterMapper competeRegisterMapper;
    @Autowired
    private CompeteMapper competeMapper;
    @Override
    public Map<String, String> createCompeteRegister(Map<String, String> data) {
        Map<String, String> map = new HashMap<>();

        String user_name = data.get("userName");
        Integer user_id = Integer.valueOf(data.get("userId"));
        Integer rating = Integer.valueOf(data.get("rating"));
        Integer compete_id = Integer.valueOf(data.get("competeId"));

        QueryWrapper<CompeteRegister> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("user_id", user_id);
        queryWrapper.eq("compete_id", compete_id);
        if (competeRegisterMapper.selectOne(queryWrapper) != null) {
            map.put("error_message", "已成功报名");
            return map;
        }

        CompeteRegister competeRegister = new CompeteRegister(
                null,
                user_name,
                user_id,
                rating,
                0,
                compete_id,
                0
        );
        competeRegisterMapper.insert(competeRegister);

        Compete compete = competeMapper.selectById(compete_id);
        compete.setParticipant(compete.getParticipant() + 1);
        competeMapper.updateById(compete);

        map.put("error_message", "success");
        return map;
    }
}
