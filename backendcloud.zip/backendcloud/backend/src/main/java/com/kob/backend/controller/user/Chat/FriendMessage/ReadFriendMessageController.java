package com.kob.backend.controller.user.Chat.FriendMessage;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.kob.backend.service.user.Chat.FriendMessage.ReadFriendMessageService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
public class ReadFriendMessageController {
    @Autowired
    private ReadFriendMessageService readFriendMessageService;
    @PostMapping("/friendMessage/read/")
    public Map<String, String> readFriendMessage(@RequestParam Map<String, String> data) throws JsonProcessingException {
        return readFriendMessageService.readFriendMessage(data);
    }
}
