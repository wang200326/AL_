package com.kob.backend.controller.course.Video;

import com.kob.backend.service.course.Video.UpdateCourseVideoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
public class UpdateCourseVideoController {
    @Autowired
    private UpdateCourseVideoService updateCourseVideoService;

    @PostMapping("/courseVideo/update/")
    public Map<String, String> updateVideo(@RequestParam Map<String, String> data) {
        return updateCourseVideoService.updateVideo(data);
    }
}
