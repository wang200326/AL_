package com.kob.backend.service.user.account;

import java.util.Map;

public interface InfoService {
    public Map<String, String> getinfo();
}
