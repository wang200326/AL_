package com.kob.backend.controller.compete.aboutCompete;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.kob.backend.service.compete.aboutCompete.SelectCompeteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
public class SelectCompeteController {
    @Autowired
    private SelectCompeteService selectCompeteService;

    @PostMapping("/compete/select/")
    public Map<String, String> selectCompete() throws JsonProcessingException {
        return selectCompeteService.selectCompete();
    }
}
