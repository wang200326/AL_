package com.kob.backend.controller.course.Video;

import com.kob.backend.service.course.Video.CreateCourseVideoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
public class CreateCourseVideoController {
    @Autowired
    private CreateCourseVideoService createCourseVideoService;

    @PostMapping("/courseVideo/create/")
    public Map<String, String> createVideo(@RequestParam Map<String, String> data) {
        return createCourseVideoService.createVideo(data);
    }
}
