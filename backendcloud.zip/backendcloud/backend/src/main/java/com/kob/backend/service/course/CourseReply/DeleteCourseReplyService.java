package com.kob.backend.service.course.CourseReply;

import java.util.Map;

public interface DeleteCourseReplyService {
    public Map<String, String> deleteCourseReply(Map<String, String> data);
}
