package com.kob.backend.service.compete.competeRegister;

import java.util.Map;

public interface DeleteCompeteRegisterService {
    public Map<String, String> deleteCompeteRegister(Map<String, String> data);
}
