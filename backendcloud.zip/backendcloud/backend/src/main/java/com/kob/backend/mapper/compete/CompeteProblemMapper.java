package com.kob.backend.mapper.compete;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.kob.backend.pojo.compete.CompeteProblem;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface CompeteProblemMapper extends BaseMapper<CompeteProblem> {

}
