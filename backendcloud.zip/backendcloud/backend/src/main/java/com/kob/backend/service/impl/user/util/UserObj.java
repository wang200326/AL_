package com.kob.backend.service.impl.user.util;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class UserObj { // 用于传精简版的用户
    private Integer id;
    private String username;
    private String name;
    private String photo;
}
