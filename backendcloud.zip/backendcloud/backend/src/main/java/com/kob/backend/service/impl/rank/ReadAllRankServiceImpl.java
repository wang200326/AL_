package com.kob.backend.service.impl.rank;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.kob.backend.mapper.UserMapper;
import com.kob.backend.pojo.User;
import com.kob.backend.service.rank.ReadAllRankService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class ReadAllRankServiceImpl implements ReadAllRankService {
    @Autowired
    private UserMapper userMapper;
    @Autowired
    private ObjectMapper objectMapper;
    @Override
    public Map<String, String> readAllRank() throws JsonProcessingException {
        Map<String, String> map = new HashMap<>();

        QueryWrapper<User> queryWrapper = new QueryWrapper<>();
        queryWrapper.orderByDesc("rating");
        List<User> list = userMapper.selectList(queryWrapper);
        List<UserRank> list1 = new ArrayList<>();
        for (User t : list) {
            UserRank userRank = new UserRank(
                    t.getId(),
                    t.getName(),
                    t.getUserrank(),
                    t.getRating()
            );
            list1.add(userRank);
        }

        String value =  objectMapper.writeValueAsString(list1);

        map.put("error_message", "success");
        map.put("list", value);

        return map;
    }
}
