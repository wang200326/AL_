package com.kob.backend.service.impl.question;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.kob.backend.mapper.question.QuestionMapper;
import com.kob.backend.pojo.question.Question;
import com.kob.backend.service.question.SelectQuestionListService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.*;

@Service
public class SelectQuestionListServiceImpl implements SelectQuestionListService {
    @Autowired
    private QuestionMapper questionMapper;


    @Override
    public Map<String, String> selectByAlTag(Map<String, String> data) {
        Map<String, String> map = new HashMap<>();
        ObjectMapper objectMapper = new ObjectMapper();

        String list = data.get("list");
        String option = data.get("option");
        String input = data.get("input");
        String pbfrom = data.get("pbfrom"); // 传入进来的pb
        String[] lists = new String[0];

        try {
            lists = objectMapper.readValue(list, String[].class);
            // 现在，stringArray 就是包含字符串的数组
            // 可以使用这个数组进行进一步的操作
        } catch (IOException e) {
            e.printStackTrace();
            // 在处理转换时发生异常的情况下，这里会捕获并处理异常
        }



        if (lists.length == 0 && Objects.equals(option, "") && Objects.equals(input, "") && Objects.equals(pbfrom, "1")) { // 说明没有条件 要返回所有
//            System.err.println("说明前端传了空信息过来");
            map.put("error_message", "success");
            String new_value = null;
            try {
                new_value = objectMapper.writeValueAsString(questionMapper.selectList(null)); // 返回所有内容
            } catch (JsonProcessingException e) {
                e.printStackTrace();
                // 处理异常
            }
            map.put("list", new_value);
            return map;
        }


        QueryWrapper<Question> queryWrapper = new QueryWrapper<>();
        if (Objects.equals(pbfrom, "2")) queryWrapper.eq("pbfrom", "入门与面试");
        if (Objects.equals(pbfrom, "3")) queryWrapper.eq("pbfrom", "CodeForces");
        if (Objects.equals(pbfrom, "4")) queryWrapper.eq("pbfrom", "AtCoder");

        for (String s : lists) queryWrapper.like("altag", "%" + s + "%");

        if (!Objects.equals(option, ""))  queryWrapper.eq("difficulty", option);

        if (!Objects.equals(input, "")) // 说明是空嘛 为了防止全部查询到 直接给一个不存在的东西
            queryWrapper.and(
                    wrapper -> wrapper.eq("pbid", input).or().like("name", "%" + input + "%")
            );


//        System.err.println("list == > " + list + "\noption == > " + option + "\ninput == > " + input + "\npbfrom == > " + pbfrom);

//        if (pbfrom == "1"){
//            String[] finalLists = lists;
//            String finalInput = input;
//            queryWrapper.and(wrapper -> {
//                        for (String value : finalLists) {
//                            wrapper.or().like("altag", "%" + value + "%");
//                        }
//                        wrapper.or().eq("difficulty", option)
//                                .or().like("name", "%" + finalInput + "%")
//                                .or().like("pbid", "%" + finalInput + "%");
//                    });
//        } else {
//            String[] finalLists = lists;
//            String finalInput = input;
//            queryWrapper.eq("pbfrom", pbfrom)
//                    .and(wrapper -> {
//                        for (String value : finalLists) {
//                            wrapper.or().like("altag", "%" + value + "%");
//                        }
//                        wrapper.or().eq("difficulty", option)
//                                .or().like("name", "%" + finalInput + "%")
//                                .or().like("pbid", "%" + finalInput + "%");
//                    });
//        }



        List<Question> L = questionMapper.selectList(queryWrapper);

//        if (L.isEmpty()) {
//            map.put("error_message", "没有满足条件的题目");
//            map.put("list", null);
//            return map;
//        }

        String new_value = null;

        try {
            new_value = objectMapper.writeValueAsString(L);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
            // 处理异常
        }

        map.put("error_message", "success");
        map.put("list", new_value);
        return map;
    }
}
