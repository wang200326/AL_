package com.kob.backend.mapper.postMessage;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.kob.backend.pojo.postMessage.MessageReply;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface MessageReplyMapper extends BaseMapper<MessageReply> {
}
