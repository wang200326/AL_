package com.kob.backend.service.postMessage.AboutMessage;

import java.util.Map;

public interface DeleteMessageService {
    public Map<String, String> deleteMessage(Map<String, String> data);
}
