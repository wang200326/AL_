package com.kob.backend.controller.compete.aboutCompete;

import com.kob.backend.service.compete.aboutCompete.DeleteCompeteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
public class DeleteCompeteController {
    @Autowired
    private DeleteCompeteService deleteCompeteService;

    @PostMapping("/compete/delete/")
    public Map<String, String> deleteCompete(@RequestParam Map<String, String> data) {
        return deleteCompeteService.deleteCompete(data);
    }
}
