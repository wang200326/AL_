package com.kob.backend.service.question.example;

import java.util.Map;

public interface DeleteExampleService { // 需要按照题目的pbid来删除的
    public Map<String, String> delete(Map<String, String> data);
}
