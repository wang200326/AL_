package com.kob.backend.service.impl.question;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.kob.backend.mapper.question.QuestionMapper;
import com.kob.backend.pojo.question.Question;
import com.kob.backend.service.question.UpdateQuestionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

@Service
public class UpdateQuestionServiceImpl implements UpdateQuestionService {
    @Autowired
    private QuestionMapper questionMapper;

    @Override
    public Map<String, String> update(Map<String, String> data) {
        Integer id = Integer.valueOf(data.get("id"));
        Integer pbid = Integer.valueOf(data.get("pbid")); // 这个才是题号
        String name = data.get("name");
        String difficulty = data.get("difficulty"); // 难度
        String altag = data.get("altag"); // 算法标签
        String problemcontent = data.get("problemcontent"); // 题目描述
        String input = data.get("input"); // 这个是输入格式
        String output = data.get("output"); // 这个是输出格式
        String inexample = data.get("inexample"); // 这个是输入样例
        String outexample = data.get("outexample"); // 这个是输出样例
        String pbrange = data.get("range"); // 数据范围
        String tm = data.get("tm"); // 这个是时空复杂度
        String pbfrom = data.get("pbfrom"); // 这个是来源

        Map<String, String> map = new HashMap<>();
        QueryWrapper<Question> queryWrapper = new QueryWrapper<>();
        queryWrapper.ne("id", id);
        queryWrapper.eq("pbid", pbid);
        List<Question> questions = questionMapper.selectList(queryWrapper); // 找到所有和当前题目id不一样但pbid一样的题目集

        if (pbid <= 0) {
            map.put("error_message", "pbid不能小于等于0");
            return map;
        } else if (!questions.isEmpty()) { // 其次要保证不能是其他题目的pbid
            map.put("error_message", "与当前题目不一样的pbid已经存在");
            return map;
        }

        if (Objects.equals(name, "") || name.isEmpty()) {
            map.put("error_message", "名字不能为空");
            return map;
        } else if (name.length() > 100) {
            map.put("error_message", "名字长度不能超过100字符");
            return map;
        }

        if (Objects.equals(difficulty, "") || difficulty.isEmpty()) {
            map.put("error_message", "难度不能为空");
            return map;
        } else if (difficulty.length() > 10) {
            map.put("error_message", "难度长度不能超过10字符");
            return map;
        }

        if (Objects.equals(altag, "") || altag.isEmpty()) {
            map.put("error_message", "算法标签不能为空");
            return map;
        } else if (altag.length() > 500) {
            map.put("error_message", "难度长度不能超过500字符");
            return map;
        }

        if (Objects.equals(problemcontent, "") || problemcontent.isEmpty()) {
            map.put("error_message", "题目描述不能为空");
            return map;
        } else if (problemcontent.length() > 1000) {
            map.put("error_message", "题目描述的长度不能超过1000字符");
            return map;
        }

        if (Objects.equals(input, "") || input.isEmpty()) {
            map.put("error_message", "输入格式不能为空");
            return map;
        } else if (input.length() > 500) {
            map.put("error_message", "输入格式长度不能超过500字符");
            return map;
        }

        if (Objects.equals(output, "") || output.isEmpty()) {
            map.put("error_message", "输出格式不能为空");
            return map;
        } else if (output.length() > 500) {
            map.put("error_message", "输出格式长度不能超过500字符");
            return map;
        }

        if (Objects.equals(inexample, "") || inexample.isEmpty()) {
            map.put("error_message", "输入样例不能为空");
            return map;
        } else if (inexample.length() > 500) {
            map.put("error_message", "输入样例长度不能超过500字符");
            return map;
        }

        if (Objects.equals(outexample, "") || outexample.isEmpty()) {
            map.put("error_message", "输出样例不能为空");
            return map;
        } else if (outexample.length() > 500) {
            map.put("error_message", "输出样例长度不能超过500字符");
            return map;
        }

        if (Objects.equals(pbrange, "") || pbrange.isEmpty()) {
            map.put("error_message", "数据范围不能为空");
            return map;
        } else if (pbrange.length() > 100) {
            map.put("error_message", "数据范围长度不能超过100字符");
            return map;
        }

        if (Objects.equals(tm, "") || tm.isEmpty()) {
            map.put("error_message", "时空复杂度不能为空");
            return map;
        } else if (tm.length() > 100) {
            map.put("error_message", "时空复杂度长度不能超过100字符");
            return map;
        }

        if (Objects.equals(pbfrom, "") || pbfrom.isEmpty()) {
            map.put("error_message", "来源不能为空");
            return map;
        } else if (pbfrom.length() > 100) {
            map.put("error_message", "来源长度不能超过100字符");
            return map;
        }

        UpdateWrapper<Question> updateWrapper = new UpdateWrapper<>();
        updateWrapper.set("pbid", pbid);
        updateWrapper.set("name", name);
        updateWrapper.set("difficulty", difficulty);
        updateWrapper.set("altag", altag);
        updateWrapper.set("problemcontent", problemcontent);
        updateWrapper.set("input", input);
        updateWrapper.set("output", output);
        updateWrapper.set("inexample", inexample);
        updateWrapper.set("outexample", outexample);
        updateWrapper.set("pbrange", pbrange);
        updateWrapper.set("tm", tm);
        updateWrapper.set("pbfrom", pbfrom);
        updateWrapper.eq("id", id);

        Question question = questionMapper.selectById(id);

        questionMapper.update(question, updateWrapper);
        //然后直接更新就行了

        map.put("error_message", "success");

        return map;
    }
}
