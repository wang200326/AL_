package com.kob.backend.service.compete.aboutCompete;

import java.util.Map;

public interface DeleteCompeteService {
    public Map<String, String> deleteCompete(Map<String, String> data);
}
