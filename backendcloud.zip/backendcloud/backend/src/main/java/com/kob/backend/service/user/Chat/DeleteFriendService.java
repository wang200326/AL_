package com.kob.backend.service.user.Chat;

import java.util.Map;

public interface DeleteFriendService { // 删除好友
    public Map<String, String> deleteFriend(Map<String, String> data);
}
