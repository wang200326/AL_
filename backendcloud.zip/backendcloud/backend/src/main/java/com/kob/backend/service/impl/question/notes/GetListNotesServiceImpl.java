package com.kob.backend.service.impl.question.notes;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.kob.backend.mapper.question.NotesMapper;
import com.kob.backend.mapper.question.QuestionMapper;
import com.kob.backend.pojo.User;
import com.kob.backend.pojo.question.Notes;
import com.kob.backend.pojo.question.Question;
import com.kob.backend.service.impl.utils.UserDetailsImpl;
import com.kob.backend.service.question.notes.GetListNotesService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class GetListNotesServiceImpl implements GetListNotesService {
    @Autowired
    private NotesMapper notesMapper;
    @Autowired
    private QuestionMapper questionMapper;

    @Override
    public Map<String, String> getListNotes(Map<String, String> data) throws JsonProcessingException { // 获取所有题目对应的题解
        Map<String, String> map = new HashMap<>();
        UsernamePasswordAuthenticationToken authentication =
                (UsernamePasswordAuthenticationToken) SecurityContextHolder.getContext().getAuthentication();

        UserDetailsImpl loginUser = (UserDetailsImpl) authentication.getPrincipal();
        User user = loginUser.getUser(); // 当前登录的用户

        Integer pbid = Integer.valueOf(data.get("pbid"));

        QueryWrapper<Question> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("pbid", pbid);

        if (questionMapper.selectList(queryWrapper).isEmpty()) { // 说明没有这个题目
            map.put("error_message", "没有这个题号对应的题解");
            return map;
        }

        QueryWrapper<Notes> queryWrapper1 = new QueryWrapper<>();
        queryWrapper1.eq("pbid", pbid);
        queryWrapper1.orderByDesc("goods");
        List<Notes> list = notesMapper.selectList(queryWrapper1);
        // 这样查出来就都是点赞数高的在前面
        // 然后利用java的自定义排序实现userid相同的在前面即可

        if (user != null) {
            System.err.println("123");
//            Collections.sort(list, (Notes o1,Notes o2) -> {
////                if (Objects.equals(o1.getUserid(), user.getId()) && !Objects.equals(o2.getUserid(), user.getId())) return 0;
////                else if (!Objects.equals(o1.getUserid(), user.getId()) && Objects.equals(o2.getUserid(), user.getId())) return 1;
//                return o1.getGoods() >= o2.getGoods() ? 0 : 1;
//            });
            Collections.sort(list, (o1, o2) -> {
                if (Objects.equals(o1.getUserid(), user.getId()) && !Objects.equals(o2.getUserid(), user.getId())) {
                    return -1;
                } else if (!Objects.equals(o1.getUserid(), user.getId()) && Objects.equals(o2.getUserid(), user.getId())) {
                    return 1;
                }
                return Integer.compare(o2.getGoods(), o1.getGoods());
            });
        }

        ObjectMapper objectMapper = new ObjectMapper();
        String value = objectMapper.writeValueAsString(list);

        map.put("error_message", "success");
        map.put("list", value);
        return map;
    }
}
