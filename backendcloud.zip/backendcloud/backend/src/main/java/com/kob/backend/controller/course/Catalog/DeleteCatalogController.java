package com.kob.backend.controller.course.Catalog;

import com.kob.backend.service.course.Catalog.DeleteCatalogService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
public class DeleteCatalogController{
    @Autowired
    private DeleteCatalogService deleteCatalogService;

    @PostMapping("/catalog/delete/")
    public Map<String, String> deleteCatalog(@RequestParam Map<String, String> data) {
        return deleteCatalogService.deleteCatalog(data);
    }
}
