package com.kob.backend.service.impl.user.Chat;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.kob.backend.mapper.UserMapper;
import com.kob.backend.mapper.Chat.friendship.FriendShipMapper;
import com.kob.backend.pojo.User;
import com.kob.backend.pojo.Chat.friendship.FriendShip;
import com.kob.backend.service.impl.utils.UserDetailsImpl;
import com.kob.backend.service.user.Chat.AddFriendService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class AddFriendServiceImpl implements AddFriendService {
    @Autowired
    private FriendShipMapper friendShipMapper;
    @Autowired
    private UserMapper userMapper;

    @Override
    public Map<String, String> addFriend(Map<String, String> data) { // 前端要传 想添加人的id
        UsernamePasswordAuthenticationToken authentication =
                (UsernamePasswordAuthenticationToken) SecurityContextHolder.getContext().getAuthentication();

        UserDetailsImpl loginUser = (UserDetailsImpl) authentication.getPrincipal();
        User user = loginUser.getUser(); // 当前登录的用户

        Integer id = Integer.valueOf(data.get("id"));

        Map<String, String> map = new HashMap<>();

        QueryWrapper<FriendShip> friendShipQueryWrapper = new QueryWrapper<>();
        friendShipQueryWrapper.and(i -> i.eq("aid", id).eq("bid", user.getId()))
                .or(i -> i.eq("aid", user.getId()).eq("bid", id));
        // 看看userid和id是否有关系 有的话就不用继续做了
        List<FriendShip> friendShipList = friendShipMapper.selectList(friendShipQueryWrapper);

        if (!friendShipList.isEmpty()) {
            map.put("error_message", "已经存在好友关系了");
            return map;
        }

        QueryWrapper<User> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("id", id);
        User user1 = userMapper.selectOne(queryWrapper);
        if (user1 == null) {
            map.put("error_message", "用户不存在");
            return map;
        }

        FriendShip friendShip = new FriendShip(
                null,
                user.getId(),
                user.getName(),
                user.getPhoto(),
                user.getUsername(),
                user1.getId(),
                user1.getName(),
                user1.getPhoto(),
                user1.getUsername()
        );
        friendShipMapper.insert(friendShip);
        map.put("error_message", "success");

        return map;
    }
}
