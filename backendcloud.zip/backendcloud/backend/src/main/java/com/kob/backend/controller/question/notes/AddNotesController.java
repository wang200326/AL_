package com.kob.backend.controller.question.notes;

import com.kob.backend.service.question.notes.AddNotesService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
public class AddNotesController {
    @Autowired
    private AddNotesService addNotesService;

    @PostMapping("/notes/add/")
    public Map<String, String> addNotes(@RequestParam Map<String, String> data) {
        return addNotesService.addNotes(data);
    }
}
