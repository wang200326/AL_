package com.kob.backend.controller.user.Chat;

import com.kob.backend.service.user.Chat.SearchFriendService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
public class SearchFriendController {
    @Autowired
    private SearchFriendService searchFriendService;

    @PostMapping("/friend/search/")
    public Map<String, String> searchFriend(@RequestParam Map<String, String> data) {
        return searchFriendService.searchFriend(data);
    }
}
