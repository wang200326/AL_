package com.kob.backend.service.compete.competeProblem;

import java.util.Map;

public interface DeleteCompeteProblemService {
    public Map<String, String> deleteCompeteProblem(Map<String, String> data);
}
