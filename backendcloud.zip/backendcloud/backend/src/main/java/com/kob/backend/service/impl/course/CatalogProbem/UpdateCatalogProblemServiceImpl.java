package com.kob.backend.service.impl.course.CatalogProbem;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.kob.backend.mapper.course.CatalogProblemMapper;
import com.kob.backend.mapper.question.QuestionMapper;
import com.kob.backend.pojo.course.CatalogProblem;
import com.kob.backend.pojo.question.Question;
import com.kob.backend.service.course.CatalogProblem.UpdateCatalogProblemService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

@Service
public class UpdateCatalogProblemServiceImpl implements UpdateCatalogProblemService {
    @Autowired
    private CatalogProblemMapper catalogProblemMapper;
    @Autowired
    private QuestionMapper questionMapper;

    @Override
    public Map<String, String> updateCatalogProblem(Map<String, String> data) {
        Map<String, String> map = new HashMap<>();

        String Id = data.get("id");
        String pbId = data.get("pbid");
        if (Objects.equals(Id, "") || Id == null) {
            map.put("error_message", "Id不能为空");
            return map;
        }
        if (Objects.equals(pbId, "") || pbId == null) {
            map.put("error_message", "pbid不能为空");
            return map;
        }

        Integer id = Integer.valueOf(Id);
        Integer pbid = Integer.valueOf(pbId);
        String title = data.get("title");
        CatalogProblem catalogProblem = catalogProblemMapper.selectById(id);
        if (title == "" || title == null) {
            map.put("error_message", "title不能为空");
            return map;
        } else if (title.length() > 100) {
            map.put("error_message", "title不能超过100个字符");
            return map;
        }

        if (catalogProblem == null) { // 看看习题存在不存在
            map.put("error_message", "id对应的习题不存在");
            return map;
        }

        QueryWrapper<Question> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("pbid", pbid);
        Question question =  questionMapper.selectOne(queryWrapper);

        if (question == null) {
            map.put("error_message", "pbid对应的题目不存在");
            return map;
        }

        UpdateWrapper<CatalogProblem> updateWrapper = new UpdateWrapper<>();
        updateWrapper.eq("id", id);
        updateWrapper.set("pbid", pbid);
        updateWrapper.set("title", title);
        updateWrapper.set("problem_name", question.getName());

        catalogProblemMapper.update(null, updateWrapper);

        map.put("error_message", "success");

        return map;
    }
}
