package com.kob.backend.service.question;


import com.kob.backend.pojo.question.Question;

import java.util.List;

public interface GetQuestionListService {
    public List<Question> getList();
}
