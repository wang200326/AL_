package com.kob.backend.service.course.CourseTalk;

import java.util.Map;

public interface CreateCourseTalkService {
    public Map<String, String> createCourseTalk(Map<String, String> data);
}
