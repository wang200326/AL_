package com.kob.backend.controller.user.Chat;

import com.kob.backend.service.user.Chat.AddFriendService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
public class AddFriendController {
    @Autowired
    private AddFriendService addFriendService;

    @PostMapping("/friend/add/")
    public Map<String, String> addFriend(@RequestParam Map<String, String> data) {
        return addFriendService.addFriend(data);
    }
}
