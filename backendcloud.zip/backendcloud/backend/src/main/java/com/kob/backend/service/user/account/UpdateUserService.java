package com.kob.backend.service.user.account;

import java.util.Map;

public interface UpdateUserService {
    public Map<String, String> update(Map<String, String> data);
}
