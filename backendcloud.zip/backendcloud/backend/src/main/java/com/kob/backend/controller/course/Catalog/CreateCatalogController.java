package com.kob.backend.controller.course.Catalog;

import com.kob.backend.service.course.Catalog.CreateCatalogService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
public class CreateCatalogController {
    @Autowired
    private CreateCatalogService createCatalogService;

    @PostMapping("/catalog/create/")
    public Map<String, String> createCatalog(@RequestParam Map<String, String> data) {
        return createCatalogService.createCatalog(data);
    }
}
