package com.kob.backend.service.impl.question.notes;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.kob.backend.mapper.question.NotesMapper;
import com.kob.backend.pojo.question.Notes;
import com.kob.backend.service.question.notes.GetOneNotesService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

@Service
public class GetOneNotesServiceImpl implements GetOneNotesService {
    @Autowired
    private NotesMapper notesMapper;

    @Override
    public Map<String, String> getOne(Map<String, String> data) throws JsonProcessingException { // 前端会传一个id过来
        Map<String, String> map = new HashMap<>();

        Integer id = Integer.valueOf(data.get("id"));

        Notes notes = notesMapper.selectById(id); // 找到这个题解
        if (notes == null) { // 说明这个题解没了
            map.put("error_message", "没有这个id对应的题解");
            return map;
        }

        // 到了这里说明 notes 就是我们要的题解
        ObjectMapper objectMapper = new ObjectMapper();

        String one = objectMapper.writeValueAsString(notes);
        map.put("one", one);
        map.put("error_message", "success");
//        map.put("pbid", String.valueOf(notes.getPbid()));
//        map.put("title", notes.getTitle());
//        map.put("markdown", notes.getMarkdown());
//        map.put("content", notes.getContent());
//        map.put("userid", String.valueOf(notes.getUserid()));
//        map.put("name", notes.getName());
//        map.put("photo", notes.getPhoto());
//        map.put("createtime", String.valueOf(notes.getCreatetime()));
//        map.put("goods", String.valueOf(notes.getGoods()));
        return map;
    }
}
