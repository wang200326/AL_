package com.kob.backend.service.impl.course.Video;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.kob.backend.mapper.course.CatalogMapper;
import com.kob.backend.mapper.course.CourseVideoMapper;
import com.kob.backend.pojo.course.CourseVideo;
import com.kob.backend.service.course.Video.ReadCourseVideoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

@Service
public class ReadCourseVideoServiceImpl implements ReadCourseVideoService {
    @Autowired
    private CourseVideoMapper courseVideoMapper;
    @Autowired
    private ObjectMapper objectMapper;
    @Autowired
    private CatalogMapper catalogMapper;
    @Override
    public Map<String, String> readVideo(Map<String, String> data) throws JsonProcessingException {
        Map<String, String> map = new HashMap<>();

        String Catalog_id = data.get("catalogId");

        if (Objects.equals(Catalog_id, "") || Catalog_id == null) {
            map.put("error_message", "catalogId为空");
            return map;
        }

        Integer catalog_id = Integer.valueOf(Catalog_id);
        if (catalogMapper.selectById(catalog_id) == null) {
            map.put("error_message", "不存在对应目录");
            return map;
        }

        QueryWrapper<CourseVideo> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("catalog_id", catalog_id);
        queryWrapper.orderByAsc("number");
        List<CourseVideo> list = courseVideoMapper.selectList(queryWrapper);
//        System.err.println("list == >" + list);
        if (list.isEmpty()) {
            map.put("error_message", "暂未录入课程视频");
            return map;
        }

        String value = objectMapper.writeValueAsString(list);
        map.put("error_message", "success");
        map.put("list", value);

        return map;
    }
}
