package com.kob.backend.controller.postMessage.AboutMessage;

import com.kob.backend.service.postMessage.AboutMessage.CreateMessageService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
public class CreateMessageController {
    @Autowired
    private CreateMessageService createMessageService;
    @PostMapping("/postMessage/create/")
    public Map<String, String> createMessage(@RequestParam Map<String, String> data) {
        return createMessageService.createMessage(data);
    }
}
