package com.kob.backend.service.impl.user.Chat;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.kob.backend.mapper.Chat.friendship.FriendShipMapper;
import com.kob.backend.pojo.User;
import com.kob.backend.pojo.Chat.friendship.FriendShip;
import com.kob.backend.service.impl.utils.UserDetailsImpl;
import com.kob.backend.service.user.Chat.DeleteFriendService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class DeleteFriendServiceImpl implements DeleteFriendService {
    @Autowired
    private FriendShipMapper friendShipMapper;
    @Override
    public Map<String, String> deleteFriend(Map<String, String> data) {
        UsernamePasswordAuthenticationToken authentication =
                (UsernamePasswordAuthenticationToken) SecurityContextHolder.getContext().getAuthentication();

        UserDetailsImpl loginUser = (UserDetailsImpl) authentication.getPrincipal();
        User user = loginUser.getUser(); // 当前登录的用户

        Integer id = Integer.valueOf(data.get("id"));
        Map<String, String> map = new HashMap<>();

        // 首先来找二者好友关系捏
        QueryWrapper<FriendShip> friendShipQueryWrapper = new QueryWrapper<>();
        friendShipQueryWrapper.and(i -> i.eq("aid", id).eq("bid", user.getId()))
                .or(i -> i.eq("aid", user.getId()).eq("bid", id));
        // 看看userid和id是否有关系 有的话就不用继续做了
        List<FriendShip> friendShipList = friendShipMapper.selectList(friendShipQueryWrapper);

        if (friendShipList.isEmpty()) {
            map.put("error_message", "已经不是好友关系，对方已把你删除");
            return map;
        }

        friendShipMapper.delete(friendShipQueryWrapper);
        map.put("error_message", "success");

        return map;
    }
}
