package com.kob.backend.service.course.Catalog;

import com.fasterxml.jackson.core.JsonProcessingException;

import java.util.Map;

public interface DeleteCatalogService {
    public Map<String, String> deleteCatalog(Map<String, String> data);
}
