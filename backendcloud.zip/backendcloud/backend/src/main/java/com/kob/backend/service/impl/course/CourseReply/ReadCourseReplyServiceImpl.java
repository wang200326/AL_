package com.kob.backend.service.impl.course.CourseReply;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.kob.backend.mapper.course.CourseReplyMapper;
import com.kob.backend.pojo.course.CourseReply;
import com.kob.backend.service.course.CourseReply.ReadCourseReplyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class ReadCourseReplyServiceImpl implements ReadCourseReplyService {
    @Autowired
    private CourseReplyMapper courseReplyMapper;
    @Autowired
    private ObjectMapper objectMapper;
    @Override
    public Map<String, String> readCourseReply(Map<String, String> data) throws JsonProcessingException {
        Map<String, String> map = new HashMap<>();

        Integer card_id = Integer.valueOf(data.get("cardId"));

        QueryWrapper<CourseReply> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("card_id", card_id);
        List<CourseReply> list = courseReplyMapper.selectList(queryWrapper);

        if (list.isEmpty()) {
            map.put("error_message", "没有回复");
            return map;
        }

        String value = objectMapper.writeValueAsString(list);

        map.put("error_message", "success");
        map.put("list", value);
        return map;
    }
}
