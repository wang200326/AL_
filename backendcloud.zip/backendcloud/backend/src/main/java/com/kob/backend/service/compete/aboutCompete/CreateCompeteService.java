package com.kob.backend.service.compete.aboutCompete;

import java.util.Map;

public interface CreateCompeteService {
    public Map<String, String> createCompete(Map<String, String> data);
}
