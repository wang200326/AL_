package com.kob.backend.service.question.notes;

import java.util.Map;

public interface DeleteNotesService { // 删除题解捏
    public Map<String, String> deleteNotes(Map<String, String> data);
}
