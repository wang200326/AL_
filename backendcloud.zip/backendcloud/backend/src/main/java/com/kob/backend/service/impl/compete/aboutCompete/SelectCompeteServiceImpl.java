package com.kob.backend.service.impl.compete.aboutCompete;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.kob.backend.mapper.compete.CompeteMapper;
import com.kob.backend.pojo.compete.Compete;
import com.kob.backend.service.compete.aboutCompete.SelectCompeteService;
import com.kob.backend.service.impl.compete.CompeteObj;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.TimeUnit;

@Service
public class SelectCompeteServiceImpl implements SelectCompeteService {
    @Autowired
    private CompeteMapper competeMapper;
    @Autowired
    private ObjectMapper objectMapper;
    @Override
    public Map<String, String> selectCompete() throws JsonProcessingException {
        Map<String, String> map = new HashMap<>();

        // 开始时间 > 当前时间 == 》 可以报名
        // 结束时间 < 当前时间 == 》 已结束
        // 开始时间 < 当前时间 < 结束时间 == 》 已开始


        List<Compete> list = competeMapper.selectList(null);
        Date newDate = new Date(); // 举例：当前时间

        // 获取中国时区
        TimeZone chinaTimeZone = TimeZone.getTimeZone("Asia/Shanghai");

        // 创建 Calendar 对象，并设置为中国时区
        Calendar chinaCalendar = Calendar.getInstance(chinaTimeZone);

        // 获取当前中国时区时间
        Date currentChinaTime = chinaCalendar.getTime();



        List<CompeteObj> register = new ArrayList<>();
        List<CompeteObj> alreadyStarted = new ArrayList<>();
        List<CompeteObj> finish = new ArrayList<>();

        for (Compete item : list) {
            if (item.getStartTime().compareTo(currentChinaTime) <= 0 &&
                item.getCloseTime().compareTo(currentChinaTime) >= 0) {

                Date startDate = item.getStartTime(); // 第一个日期对象，比如开始时间
                Date endDate = item.getCloseTime(); // 第二个日期对象，比如结束时间

                // 计算两个日期之间的时间差（毫秒数）
                long durationInMillis = endDate.getTime() - startDate.getTime();

                // 转换为小时和分钟
                long hours = TimeUnit.MILLISECONDS.toHours(durationInMillis);
                long minutes = TimeUnit.MILLISECONDS.toMinutes(durationInMillis) % 60;

                CompeteObj competeObj = new CompeteObj(
                        item.getId(),
                        item.getTitle(),
                        item.getStartTime(),
                        item.getCloseTime(),
                        item.getImage(),
                        item.getParticipant(),
                        item.getContent(),
                        hours + "小时" + minutes + "分钟"
                );

                alreadyStarted.add(competeObj);
            } else if (item.getStartTime().compareTo(currentChinaTime) > 0) {
                Date startDate = item.getStartTime(); // 第一个日期对象，比如开始时间
                Date endDate = item.getCloseTime(); // 第二个日期对象，比如结束时间

                // 计算两个日期之间的时间差（毫秒数）
                long durationInMillis = endDate.getTime() - startDate.getTime();

                // 转换为小时和分钟
                long hours = TimeUnit.MILLISECONDS.toHours(durationInMillis);
                long minutes = TimeUnit.MILLISECONDS.toMinutes(durationInMillis) % 60;

                CompeteObj competeObj = new CompeteObj(
                        item.getId(),
                        item.getTitle(),
                        item.getStartTime(),
                        item.getCloseTime(),
                        item.getImage(),
                        item.getParticipant(),
                        item.getContent(),
                        hours + "小时" + minutes + "分钟"
                );

                register.add(competeObj);
            } else {
                Date startDate = item.getStartTime(); // 第一个日期对象，比如开始时间
                Date endDate = item.getCloseTime(); // 第二个日期对象，比如结束时间

                // 计算两个日期之间的时间差（毫秒数）
                long durationInMillis = endDate.getTime() - startDate.getTime();

                // 转换为小时和分钟
                long hours = TimeUnit.MILLISECONDS.toHours(durationInMillis);
                long minutes = TimeUnit.MILLISECONDS.toMinutes(durationInMillis) % 60;

                CompeteObj competeObj = new CompeteObj(
                        item.getId(),
                        item.getTitle(),
                        item.getStartTime(),
                        item.getCloseTime(),
                        item.getImage(),
                        item.getParticipant(),
                        item.getContent(),
                        hours + "小时" + minutes + "分钟"
                );

                finish.add(competeObj);
            }
        }

        String enter = null;
        if (!register.isEmpty()) enter =  objectMapper.writeValueAsString(register);
        String already = null;
        if (!alreadyStarted.isEmpty()) already = objectMapper.writeValueAsString(alreadyStarted);
        String finished = null;
        if (!finish.isEmpty()) finished = objectMapper.writeValueAsString(finish);

        map.put("error_message", "success");
        map.put("register", enter);
        map.put("already", already);
        map.put("finish", finished);
        return map;
    }
}
