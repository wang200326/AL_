package com.kob.backend.controller.course.CatalogProblem;

import com.kob.backend.service.course.CatalogProblem.DeleteCatalogProblemService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
public class DeleteCatalogProblemController {
    @Autowired
    private DeleteCatalogProblemService deleteCatalogProblemService;

    @PostMapping("/catalogProblem/delete/")
    public Map<String, String> deleteCatalogProblem(@RequestParam Map<String, String> data) {
        return deleteCatalogProblemService.deleteCatalogProblem(data);
    }
}
