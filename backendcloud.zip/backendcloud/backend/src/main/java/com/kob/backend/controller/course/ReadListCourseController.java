package com.kob.backend.controller.course;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.kob.backend.service.course.ReadListCourseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
public class ReadListCourseController {
    @Autowired
    private ReadListCourseService readListCourseService;

    @GetMapping("/course/read/list/")
    public Map<String, String> readListCourse() throws JsonProcessingException {
        return readListCourseService.readListCourse();
    }
}
