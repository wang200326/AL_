package com.kob.backend.controller.question.notes;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.kob.backend.service.question.notes.GetOneNotesService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
public class GetOneNotesController {
    @Autowired
    private GetOneNotesService getOneNotesService;

    @PostMapping("/notes/getone/")
    public Map<String, String> getOne(@RequestParam Map<String, String> data) throws JsonProcessingException {
        return getOneNotesService.getOne(data);
    }
}
