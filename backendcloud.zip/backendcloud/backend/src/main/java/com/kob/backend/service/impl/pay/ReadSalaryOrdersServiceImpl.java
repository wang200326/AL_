package com.kob.backend.service.impl.pay;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.kob.backend.mapper.Order.OrdersMapper;
import com.kob.backend.pojo.Order.Orders;
import com.kob.backend.service.pay.ReadSalaryOrdersService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class ReadSalaryOrdersServiceImpl implements ReadSalaryOrdersService {
    @Autowired
    private OrdersMapper ordersMapper;
    @Autowired
    private ObjectMapper objectMapper;
    @Override
    public Map<String, String> readSalary() throws JsonProcessingException {
        Map<String, String> map = new HashMap<>();

        List<Orders> list = ordersMapper.selectList(null);

        if (list.isEmpty()) {
            map.put("error_message", "没有购买记录");
            return map;
        }

        map.put("error_message", "success");
        map.put("list", objectMapper.writeValueAsString(list));

        return map;
    }
}
