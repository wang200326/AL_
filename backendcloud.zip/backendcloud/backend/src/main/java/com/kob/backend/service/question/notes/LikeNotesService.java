package com.kob.backend.service.question.notes;

import java.util.Map;

public interface LikeNotesService {
    public Map<String, String> likeNotes(Map<String, String> data);
}
