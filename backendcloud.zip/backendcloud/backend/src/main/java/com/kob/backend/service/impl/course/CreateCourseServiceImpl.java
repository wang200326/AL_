package com.kob.backend.service.impl.course;

import com.kob.backend.mapper.course.CourseMapper;
import com.kob.backend.pojo.course.Course;
import com.kob.backend.service.course.CreateCourseService;
import com.kob.backend.service.impl.course.uitl.Check;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

@Service
public class CreateCourseServiceImpl implements CreateCourseService {
    @Autowired
    private CourseMapper courseMapper;

    @Override
    public Map<String, String> createCourse(Map<String, String> data) {
        Map<String, String> map = new HashMap<>();
        String course_name = data.get("course_name");
        String photo = data.get("photo");
        Integer price = Integer.valueOf(data.get("price")); // 可以不写 但是前端不许传一个null进来
        String course_about = data.get("course_about");
        String words = data.get("words");

        Check obj = new Check();
        Map<String, String> new_map = obj.check(data);
        if (new_map != null) {
            return new_map;
        }
//        if (course_name == null || course_name.isEmpty()) {
//            map.put("error_message", "课程名字不能为空");
//            return map;
//        } else if (course_name.length() > 100) {
//            map.put("error_message", "课程名字长度不能超过100字符");
//            return map;
//        }
//
//        if (photo == null || photo.isEmpty()) {
//            map.put("error_message", "照片不能为空");
//            return map;
//        } else if (photo.length() > 1000) {
//            map.put("error_message", "照片长度不能超过1000字符");
//            return map;
//        }
//
//        if (course_about == null || course_about.isEmpty()) {
//            map.put("error_message", "课程简介不能为空");
//            return map;
//        } else if (course_about.length() > 1000) {
//            map.put("error_message", "课程简介长度不能超过1000字符");
//            return map;
//        }
//
//        if (words == null || words.isEmpty()) {
//            map.put("error_message", "短介绍不能为空");
//            return map;
//        } else if (words.length() > 1000) {
//            map.put("error_message", "短介绍长度不能超过1000字符");
//            return map;
//        }
//
//        if (price < 0) {
//            map.put("error_message", "价格不能小于0");
//            return map;
//        }

        Date now = new Date();

        Course course = new Course(
                null,
                course_name,
                photo,
                0,
                price,
                course_about,
                words,
                now
        );
        courseMapper.insert(course);

        map.put("error_message", "success");
        return map;
    }
}
