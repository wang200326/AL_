package com.kob.backend.service.impl.question.example;

import com.kob.backend.mapper.question.PbExampleMapper;
import com.kob.backend.service.question.example.DeleteExampleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

@Service
public class DeleteExampleServiceImpl implements DeleteExampleService { // 删除的话 因为是删一个 所以是根据id来删除
    @Autowired
    private PbExampleMapper pbExampleMapper;
    @Override
    public Map<String, String> delete(Map<String, String> data) {
        Map<String, String> map = new HashMap<>();

        Integer id = Integer.valueOf(data.get("id"));
        pbExampleMapper.deleteById(id);

        map.put("error_message", "success");
        return map;
    }
}
