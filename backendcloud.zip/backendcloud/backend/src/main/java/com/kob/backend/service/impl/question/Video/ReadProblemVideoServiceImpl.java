package com.kob.backend.service.impl.question.Video;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.kob.backend.mapper.question.ProblemVideoMapper;
import com.kob.backend.pojo.question.ProblemVideo;
import com.kob.backend.service.question.Video.ReadProblemVideoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

@Service
public class ReadProblemVideoServiceImpl implements ReadProblemVideoService {
    @Autowired
    private ProblemVideoMapper problemVideoMapper;
    @Autowired
    private ObjectMapper objectMapper;

    @Override
    public Map<String, String> readProblemVideo(Map<String, String> data) throws JsonProcessingException {
        Map<String, String> map = new HashMap<>();

        String Pbid = data.get("pbid");
        if (Objects.equals(Pbid, "") || Pbid == null) {
            map.put("error_message", "pbid为空");
            return map;
        }

        Integer pbid = Integer.valueOf(Pbid);

        QueryWrapper<ProblemVideo> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("pbid", pbid);

        ProblemVideo problemVideo = problemVideoMapper.selectOne(queryWrapper);

        if (problemVideo == null) {
            map.put("error_message", "暂无题解视频");
            return map;
        }

        String value = objectMapper.writeValueAsString(problemVideo);

        map.put("error_message", "success");
        map.put("list", value);

        return map;
    }
}
