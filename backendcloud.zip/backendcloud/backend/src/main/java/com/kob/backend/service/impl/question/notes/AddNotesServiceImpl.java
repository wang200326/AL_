package com.kob.backend.service.impl.question.notes;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.kob.backend.mapper.question.NotesMapper;
import com.kob.backend.mapper.question.QuestionMapper;
import com.kob.backend.pojo.User;
import com.kob.backend.pojo.question.Notes;
import com.kob.backend.pojo.question.Question;
import com.kob.backend.service.impl.utils.UserDetailsImpl;
import com.kob.backend.service.question.notes.AddNotesService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

@Service
public class AddNotesServiceImpl implements AddNotesService {
    @Autowired
    private NotesMapper notesMapper;

    @Autowired
    private QuestionMapper questionMapper;
    @Override
    public Map<String, String> addNotes(Map<String, String> data) { // 题解是用户自己创建的
        UsernamePasswordAuthenticationToken authentication =
                (UsernamePasswordAuthenticationToken) SecurityContextHolder.getContext().getAuthentication();

        UserDetailsImpl loginUser = (UserDetailsImpl) authentication.getPrincipal();
        User user = loginUser.getUser(); // 当前登录的用户

        // id是自增的
        Integer pbid = Integer.valueOf(data.get("pbid"));
        String markdown = data.get("markdown");
        String content = data.get("content");
        String title = data.get("title");
        // 时间后端产生就行了
        // userid这里user有的
        // 点赞数一开始就是0 可以为负数
        Map<String, String> map = new HashMap<>();

        // 为了增强鲁棒性 还是查一下pbid是否存在 万一写题解的时候管理员突然把题目删除了捏 或者修改题号了捏
        QueryWrapper<Question> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("pbid", pbid);

        if (questionMapper.selectList(queryWrapper).isEmpty()) { // 说明题目没了 或者说pbid被修改成其他号码了
            map.put("error_message", "pbid不对捏");
            return map;
        }

        if (markdown == null || markdown.isEmpty()) {
            map.put("error_message", "markdown不能为空或者null");
            return map;
        }
        else if (markdown.length() > 5000) {
            map.put("error_message", "markdown字符长度超过了5000");
            return map;
        }

        if (content == null || content.isEmpty()) {
            map.put("error_message", "content不能为空或者null");
            return map;
        }
        else if (content.length() > 100000) {
            map.put("error_message", "content字符长度超过了1000000");
            return map;
        }

        if (title == null || title.isEmpty()) {
            map.put("error_message", "title不能为空或者null");
            return map;
        }
        else if (title.length() > 100) {
            map.put("error_message", "title字符长度超过了100");
            return map;
        }

        // 可以正常添加了
        Date now = new Date(); // 返回当前时间
        Notes notes = new Notes(
                null,
                pbid,
                title,
                markdown,
                content,
                now,
                user.getId(),
                user.getName(),
                user.getPhoto(),
                0
        );
        notesMapper.insert(notes);


        map.put("error_message", "success");
        map.put("id", String.valueOf(notes.getId()));
        return map;
    }
}
