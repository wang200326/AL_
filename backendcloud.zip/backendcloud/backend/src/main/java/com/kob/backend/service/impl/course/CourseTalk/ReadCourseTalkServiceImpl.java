package com.kob.backend.service.impl.course.CourseTalk;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.kob.backend.mapper.course.CourseTalkMapper;
import com.kob.backend.pojo.course.CourseTalk;
import com.kob.backend.service.course.CourseTalk.ReadCourseTalkService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;
import java.util.List;

@Service
public class ReadCourseTalkServiceImpl implements ReadCourseTalkService {
    @Autowired
    private CourseTalkMapper courseTalkMapper;
    @Autowired
    private ObjectMapper objectMapper;

    @Override
    public Map<String, String> readCourseTalk(Map<String, String> data) throws JsonProcessingException {
        Map<String, String> map = new HashMap<>();

        Integer course_id = Integer.valueOf(data.get("courseId"));

        QueryWrapper<CourseTalk> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("course_id", course_id);

        List<CourseTalk> list = courseTalkMapper.selectList(queryWrapper);
        String value = objectMapper.writeValueAsString(list);

        map.put("error_message", "success");
        map.put("value", value);
        return map;
    }
}
