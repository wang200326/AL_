package com.kob.backend.controller.question.notes;

import com.kob.backend.service.question.notes.GetLikeNotesService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
public class GetNotesLikeController {
    @Autowired
    private GetLikeNotesService getLikeNotesService;

    @PostMapping("/notes/like/get/")
    public Map<String, String> getLike(@RequestParam Map<String, String> data) {
        return getLikeNotesService.getLike(data);
    }
}
