package com.kob.backend.service.question.Video;

import java.util.Map;

public interface UpdateProblemVideoService {
    public Map<String, String> updateProblemVideo(Map<String, String> data);
}
