package com.kob.backend.service.impl.user.Chat;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.kob.backend.mapper.UserMapper;
import com.kob.backend.mapper.Chat.friendship.FriendShipMapper;
import com.kob.backend.pojo.User;
import com.kob.backend.pojo.Chat.friendship.FriendShip;
import com.kob.backend.service.impl.user.util.UserObj;
import com.kob.backend.service.user.Chat.GetFriendService;
import org.jetbrains.annotations.NotNull;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class GetFriendServiceImpl implements GetFriendService {
    @Autowired
    private FriendShipMapper friendShipMapper;
    @Autowired
    private ObjectMapper objectMapper;
    @Autowired
    private UserMapper userMapper;
    @Override
    public Map<String, String> getFriend(Map<String, String> data) {
        Integer id = Integer.valueOf(data.get("id")); // 获取到前端传来的id 当然这里也可以直接用登录者的
        QueryWrapper<FriendShip> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("aid", id).or().eq("bid", id);

        Map<String, String> map = new HashMap<>();

        List<FriendShip> list = friendShipMapper.selectList(queryWrapper);
        if (list.isEmpty()) {
            map.put("error_message", "没有好友噢");
            return map;
        }

        System.err.println("查询的id是 == >" +   id);
        List<UserObj> lists = getUserObjs(list, id);

        String ans = null;
        try {
            ans = objectMapper.writeValueAsString(lists);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
            // 处理异常
        }

        map.put("error_message", "success");
        map.put("list", ans);
        return map;
    }

    @NotNull
    public List<UserObj> getUserObjs(List<FriendShip> list, Integer id) {
        List<UserObj> lists = new ArrayList<>();

        // id 账号 是不会变的，但是 名字 头像 是会变的 所以这里我们应该及时获取对应的用户user
        for (FriendShip f : list) {
            if (Objects.equals(f.getAid(), id)) { // 说明Bid那边是好友
                User user =  userMapper.selectById(f.getBid());
                UserObj userObj = new UserObj(f.getBid(), f.getBusername(), user.getName(), user.getPhoto());
                lists.add(userObj);
            } else {
                User user =  userMapper.selectById(f.getAid());
                UserObj userObj = new UserObj(f.getAid(), f.getAusername(), user.getName(), user.getPhoto());
                lists.add(userObj);
            }
        }
        return lists;
    }
}
