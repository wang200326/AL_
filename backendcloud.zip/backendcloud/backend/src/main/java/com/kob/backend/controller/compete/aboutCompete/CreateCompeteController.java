package com.kob.backend.controller.compete.aboutCompete;

import com.kob.backend.service.compete.aboutCompete.CreateCompeteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
public class CreateCompeteController {
    @Autowired
    private CreateCompeteService createCompeteService;

    @PostMapping("/compete/create/")
    public Map<String, String> createCompete(@RequestParam Map<String, String> data) {
        return createCompeteService.createCompete(data);
    }
}
