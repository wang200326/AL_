package com.kob.backend.controller.question;

import com.kob.backend.pojo.question.Question;
import com.kob.backend.service.question.GetQuestionListService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class GetQuestionController {
    @Autowired
    private GetQuestionListService getQuestionListService;

    @PostMapping("/question/get/")
    public List<Question> getList() {
        return getQuestionListService.getList();
    }
}
