package com.kob.backend.service.postMessage.AboutMessage;

import com.fasterxml.jackson.core.JsonProcessingException;

import java.util.Map;

public interface ReadMessageService {
    public Map<String, String> readMessage() throws JsonProcessingException;
}
