package com.kob.backend.service.postMessage.MessageLike;

import com.fasterxml.jackson.core.JsonProcessingException;

import java.util.Map;

public interface ReadMessageLikeService {
    public Map<String, String> readMessageLike(Map<String, String> data) throws JsonProcessingException;
}
