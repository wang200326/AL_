package com.kob.backend.service.user.Chat;

import java.util.Map;

public interface AddFriendService { // 加好友
    public Map<String, String> addFriend(Map<String, String> data);
}
