package com.kob.backend.service.pay;

import com.fasterxml.jackson.core.JsonProcessingException;

import java.util.Map;

public interface ReadSalaryOrdersService {
    public Map<String, String> readSalary() throws JsonProcessingException;
}
