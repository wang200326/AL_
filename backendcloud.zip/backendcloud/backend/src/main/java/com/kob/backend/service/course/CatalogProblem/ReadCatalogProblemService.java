package com.kob.backend.service.course.CatalogProblem;

import com.fasterxml.jackson.core.JsonProcessingException;

import java.util.Map;

public interface ReadCatalogProblemService {
    public Map<String, String> ReadCatalogProblem(Map<String, String> data) throws JsonProcessingException;
}
