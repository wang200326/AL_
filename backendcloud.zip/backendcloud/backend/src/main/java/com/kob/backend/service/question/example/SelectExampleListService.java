package com.kob.backend.service.question.example;

import java.util.Map;

public interface SelectExampleListService { // 需要按照题目的pbid来找的
    public Map<String, String> get(Map<String, String> data);
}
