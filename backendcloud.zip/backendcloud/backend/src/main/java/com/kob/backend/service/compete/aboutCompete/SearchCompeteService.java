package com.kob.backend.service.compete.aboutCompete;

import com.fasterxml.jackson.core.JsonProcessingException;

import java.util.Map;

public interface SearchCompeteService {
    public Map<String, String> searchCompete(Map<String, String> data) throws JsonProcessingException;
}
