package com.kob.backend.service.postMessage.MessageReply;

import java.util.Map;

public interface CreateMessageReplyService {
    public Map<String, String> createMessageReply(Map<String, String> data);
}
