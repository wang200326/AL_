package com.kob.backend.controller.compete.competeRegister;

import com.kob.backend.service.compete.competeRegister.CreateCompeteRegisterService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
public class CreateCompeteRegisterController {
    @Autowired
    private CreateCompeteRegisterService createCompeteRegisterService;
    @PostMapping("/competeRegister/create/")
    public Map<String, String> createCompeteRegister(@RequestParam Map<String, String> data) {
        return createCompeteRegisterService.createCompeteRegister(data);
    }
}
