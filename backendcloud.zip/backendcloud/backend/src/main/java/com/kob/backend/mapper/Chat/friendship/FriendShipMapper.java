package com.kob.backend.mapper.Chat.friendship;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.kob.backend.pojo.Chat.friendship.FriendShip;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface FriendShipMapper extends BaseMapper<FriendShip> {
}
