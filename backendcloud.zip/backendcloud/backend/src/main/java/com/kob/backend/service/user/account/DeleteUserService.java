package com.kob.backend.service.user.account;

import java.util.Map;

public interface DeleteUserService {
    public Map<String, String> deleteUser(Map<String, String> data);
}
