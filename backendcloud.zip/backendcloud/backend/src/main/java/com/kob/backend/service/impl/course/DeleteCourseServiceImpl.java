package com.kob.backend.service.impl.course;

import com.kob.backend.mapper.course.CourseMapper;
import com.kob.backend.pojo.course.Course;
import com.kob.backend.service.course.DeleteCourseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

@Service
public class DeleteCourseServiceImpl implements DeleteCourseService {
    @Autowired
    private CourseMapper courseMapper;

    @Override
    public Map<String, String> deleteCourse(Map<String, String> data) {
        Map<String, String> map = new HashMap<>();

        Integer id = Integer.valueOf(data.get("id"));

        Course course = courseMapper.selectById(id);

        if (course == null) {
            map.put("error_message", "不存在对应id的课程");
            return map;
        }

        courseMapper.deleteById(course);

        map.put("error_message", "success");
        return map;
    }
}
