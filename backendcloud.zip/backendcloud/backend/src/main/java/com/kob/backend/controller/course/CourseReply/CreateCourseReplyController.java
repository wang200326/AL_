package com.kob.backend.controller.course.CourseReply;

import com.kob.backend.service.course.CourseReply.CreateCourseReplyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
public class CreateCourseReplyController {
    @Autowired
    private CreateCourseReplyService createCourseReplyService;
    @PostMapping("/courseReply/create/")
    public Map<String, String> createCourseReply(@RequestParam Map<String, String> data) {
        return createCourseReplyService.createCourseReply(data);
    }
}
