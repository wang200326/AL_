package com.kob.backend.service.impl.question;

import com.kob.backend.mapper.question.QuestionMapper;
import com.kob.backend.pojo.question.Question;
import com.kob.backend.service.question.GetQuestionListService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class GetQuestionServiceImpl implements GetQuestionListService {
    @Autowired
    private QuestionMapper questionMapper;

    @Override
    public List<Question> getList() { // 这里后续需要优化 我们需要根据前端搜索的页数获取题库
        return questionMapper.selectList(null);
    }
}
