package com.kob.backend.service.compete.competeRegister;

import com.fasterxml.jackson.core.JsonProcessingException;

import java.util.Map;

public interface ReadCompeteRegisterService {
    public Map<String, String> readCompeteRegister(Map<String, String> data) throws JsonProcessingException;
}
