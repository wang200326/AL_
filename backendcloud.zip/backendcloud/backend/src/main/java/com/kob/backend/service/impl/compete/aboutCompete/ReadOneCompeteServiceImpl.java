package com.kob.backend.service.impl.compete.aboutCompete;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.kob.backend.mapper.compete.CompeteMapper;
import com.kob.backend.pojo.compete.Compete;
import com.kob.backend.service.compete.aboutCompete.ReadOneCompeteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

@Service
public class ReadOneCompeteServiceImpl implements ReadOneCompeteService {
    @Autowired
    private CompeteMapper competeMapper;
    @Autowired
    private ObjectMapper objectMapper;

    @Override
    public Map<String, String> readOneCompete(Map<String, String> data) throws JsonProcessingException {
        Map<String, String> map = new HashMap<>();

        Integer id = Integer.valueOf(data.get("id"));

        Compete compete = competeMapper.selectById(id);

        Date startDate = compete.getStartTime(); // 第一个日期对象，比如开始时间
        Date endDate = compete.getCloseTime(); // 第二个日期对象，比如结束时间

        // 计算两个日期之间的时间差（毫秒数）
        long durationInMillis = endDate.getTime() - startDate.getTime();

        // 转换为小时和分钟
        long hours = TimeUnit.MILLISECONDS.toHours(durationInMillis);
        long minutes = TimeUnit.MILLISECONDS.toMinutes(durationInMillis) % 60;

        // 输出时长
//        System.out.println("时长（小时）: " + hours);
//        System.out.println("时长（分钟）: " + minutes);

        String value = objectMapper.writeValueAsString(compete);

        map.put("error_message", "success");
        map.put("compete", value);
        map.put("time", hours + "小时" + minutes + "分钟");
        return map;
    }
}
