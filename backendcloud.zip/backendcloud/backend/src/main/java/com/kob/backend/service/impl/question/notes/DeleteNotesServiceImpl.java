package com.kob.backend.service.impl.question.notes;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.kob.backend.mapper.question.NotesMapper;
import com.kob.backend.pojo.User;
import com.kob.backend.pojo.question.Notes;
import com.kob.backend.service.impl.utils.UserDetailsImpl;
import com.kob.backend.service.question.notes.DeleteNotesService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

@Service
public class DeleteNotesServiceImpl implements DeleteNotesService {
    @Autowired
    private NotesMapper notesMapper;
    @Override
    public Map<String, String> deleteNotes(Map<String, String> data) { // 传来当前的userid 删除之前你首先要是作者才行
        Map<String, String> map = new HashMap<>();
        UsernamePasswordAuthenticationToken authentication =
                (UsernamePasswordAuthenticationToken) SecurityContextHolder.getContext().getAuthentication();

        UserDetailsImpl loginUser = (UserDetailsImpl) authentication.getPrincipal();
        User user = loginUser.getUser(); // 当前登录的用户

        Integer userid = Integer.valueOf(data.get("userid"));
        Integer id = Integer.valueOf(data.get("id"));

        if (!userid.equals(user.getId()) && user.getId() != 3) { // 保证管理员可以删除
            map.put("error_message", "不能删除别人题解");
            return map;
        }

        if (notesMapper.selectById(id) == null) {
            map.put("error_message", "题解已经不存在了");
            return map;
        }

        QueryWrapper<Notes> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("id", id);
        queryWrapper.eq("userid", userid);
        if (notesMapper.selectOne(queryWrapper) == null) {
            map.put("error_message", "根据当前的id和userid查不到对应题解");
            return map;
        }

        notesMapper.delete(queryWrapper);
        map.put("error_message", "success");
        return map;
    }
}
