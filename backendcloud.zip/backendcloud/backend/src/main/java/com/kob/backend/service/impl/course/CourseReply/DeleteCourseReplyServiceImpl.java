package com.kob.backend.service.impl.course.CourseReply;

import com.kob.backend.mapper.course.CourseReplyMapper;
import com.kob.backend.service.course.CourseReply.DeleteCourseReplyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

@Service
public class DeleteCourseReplyServiceImpl implements DeleteCourseReplyService {
    @Autowired
    private CourseReplyMapper courseReplyMapper;

    @Override
    public Map<String, String> deleteCourseReply(Map<String, String> data) {
        Map<String, String> map = new HashMap<>();

        Integer id = Integer.valueOf(data.get("id"));

        courseReplyMapper.deleteById(id);

        map.put("error_message", "success");

        return map;
    }
}
