package com.kob.backend.service.postMessage.MessageLike;

import java.util.Map;

public interface UpdateMessageLikeService {
    public Map<String, String> updateMessageLike(Map<String, String> data);
}
