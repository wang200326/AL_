package com.kob.backend.service.course.Catalog;

import java.util.Map;

public interface CreateCatalogService {
    public Map<String, String> createCatalog(Map<String, String> data);
}
