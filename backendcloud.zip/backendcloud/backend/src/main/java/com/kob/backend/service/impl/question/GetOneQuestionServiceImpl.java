package com.kob.backend.service.impl.question;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.kob.backend.mapper.question.QuestionMapper;
import com.kob.backend.pojo.question.Question;
import com.kob.backend.service.question.GetOneQuestionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

@Service
public class GetOneQuestionServiceImpl implements GetOneQuestionService {
    @Autowired
    private QuestionMapper questionMapper;
    @Autowired
    private ObjectMapper objectMapper;

    @Override
    public Map<String, String> getOne(Map<String, String> data) throws JsonProcessingException {
        Map<String, String> map = new HashMap<>();

        Integer id = Integer.valueOf(data.get("id"));
        QueryWrapper<Question> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("pbid", id);
        Question question = questionMapper.selectOne(queryWrapper);

        if (question == null) {
            map.put("error_message", "id对应的题目不存在");
            return map;
        }

        String value = objectMapper.writeValueAsString(question);
        map.put("error_message", "success");
        map.put("problem", value);

        return map;
    }
}
