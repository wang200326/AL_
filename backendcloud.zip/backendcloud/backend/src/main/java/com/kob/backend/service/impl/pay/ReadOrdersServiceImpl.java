package com.kob.backend.service.impl.pay;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.kob.backend.mapper.Order.OrdersMapper;
import com.kob.backend.pojo.Order.Orders;
import com.kob.backend.pojo.User;
import com.kob.backend.service.impl.utils.UserDetailsImpl;
import com.kob.backend.service.pay.ReadOrdersService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import javax.management.Query;
import java.util.HashMap;
import java.util.Map;
import java.util.Queue;

@Service
public class ReadOrdersServiceImpl implements ReadOrdersService {
    @Autowired
    private OrdersMapper ordersMapper;
    @Autowired
    private ObjectMapper objectMapper;
    @Override
    public Map<String, String> readOrders(Map<String, String> data) throws JsonProcessingException {
        UsernamePasswordAuthenticationToken authentication =
                (UsernamePasswordAuthenticationToken) SecurityContextHolder.getContext().getAuthentication();

        UserDetailsImpl loginUser = (UserDetailsImpl) authentication.getPrincipal();
        User user = loginUser.getUser();

        Integer course_id = Integer.valueOf(data.get("courseId"));

        QueryWrapper<Orders> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("user_id", user.getId());
        queryWrapper.eq("goods_id", course_id);
        Orders orders = ordersMapper.selectOne(queryWrapper);

        Map<String, String> map = new HashMap<>();

        if (orders == null) {
            map.put("error_message", "不存在订单捏");
            return map;
        }

        map.put("error_message", "success");
        map.put("order", objectMapper.writeValueAsString(orders));
        return map;
    }
}
