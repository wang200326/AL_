package com.kob.backend.service.user.account;

import com.fasterxml.jackson.core.JsonProcessingException;

import java.util.Map;

public interface ReadUserService {
    public Map<String, String> readUser() throws JsonProcessingException;
}
