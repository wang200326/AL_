package com.kob.backend.service.impl.postMessage.AboutMessage;

import com.kob.backend.mapper.postMessage.PostMessageMapper;
import com.kob.backend.pojo.postMessage.PostMessage;
import com.kob.backend.service.postMessage.AboutMessage.CreateMessageService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

@Service
public class CreateMessageServiceImpl implements CreateMessageService {
    @Autowired
    private PostMessageMapper postMessageMapper;

    @Override
    public Map<String, String> createMessage(Map<String, String> data) {
        Map<String, String> map = new HashMap<>();

        Integer user_id = Integer.valueOf(data.get("userId"));
        String user_name = data.get("userName");
        String content = data.get("content");
        String markdown = data.get("markdown");
        String photo = data.get("photo");

        if (Objects.equals(content, "") || content == null) {
            map.put("error_message", "未输入");
            return map;
        } else if (content.length() > 80000000) {
            map.put("error_message", "超出内容");
            return map;
        }

        if (Objects.equals(markdown, "") || markdown == null) {
            map.put("error_message", "未输入");
            return map;
        } else if (markdown.length() > 10000) {
            map.put("error_message", "超出内容");
            return map;
        }

        Date now = new Date();

        PostMessage postMessage = new PostMessage(
                null,
                user_id,
                user_name,
                content,
                markdown,
                now,
                photo,
                0
        );

        postMessageMapper.insert(postMessage);

        map.put("error_message", "success");

        return map;
    }
}
