package com.kob.backend.service.impl.question.notes;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.kob.backend.mapper.question.NotesLikeMapper;
import com.kob.backend.mapper.question.NotesMapper;
import com.kob.backend.pojo.User;
import com.kob.backend.pojo.question.Notes;
import com.kob.backend.pojo.question.NotesLike;
import com.kob.backend.service.impl.utils.UserDetailsImpl;
import com.kob.backend.service.question.notes.LikeNotesService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

@Service
public class LikeNotesServiceImpl implements LikeNotesService {
    @Autowired
    private NotesMapper notesMapper;
    @Autowired
    private NotesLikeMapper notesLikeMapper;

    @Override
    public Map<String, String> likeNotes(Map<String, String> data) {
        Map<String, String> map = new HashMap<>();
        UsernamePasswordAuthenticationToken authentication =
                (UsernamePasswordAuthenticationToken) SecurityContextHolder.getContext().getAuthentication();

        UserDetailsImpl loginUser = (UserDetailsImpl) authentication.getPrincipal();
        User user = loginUser.getUser(); // 当前登录的用户

        Integer userid = Integer.valueOf(data.get("userid"));
        Integer status = Integer.valueOf(data.get("status"));
        Integer notesid = Integer.valueOf(data.get("notesid"));

        Notes notes = notesMapper.selectById(notesid); // 找到对应题解行

        if (!userid.equals(user.getId())) {
            map.put("error_message", "用户id不一致");
            return map;
        }

        if (notes == null) {
            map.put("error_message", "题解不存在");
            return map;
        }

        System.err.println("status == >" + status);
        // 看点赞状态 1 -- 点赞 -1 -- 踩 然后查题解点赞表
        // 没点过就 加新行

        // 找到 题解id和用户id一样的行
        QueryWrapper<NotesLike> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("userid", userid);
        queryWrapper.eq("notesid", notesid);


        NotesLike nl = notesLikeMapper.selectOne(queryWrapper); // 找对应点赞题解行

        if (nl == null) { // 说明不存在 就创造一个
            nl = new NotesLike(null, notesid, status, userid);
            notesLikeMapper.insert(nl);

            UpdateWrapper<Notes> updateWrapper = new UpdateWrapper<>();
            updateWrapper.set("goods", notes.getGoods() + status);
            updateWrapper.eq("id", notesid);
            notesMapper.update(notes, updateWrapper);

            if (status == 1) {
                map.put("status", String.valueOf(1)); // 最终结果 1 0 -1
                map.put("goods", String.valueOf(notes.getGoods() + 1));
            }
            if (status == -1) {
                map.put("status", String.valueOf(-1)); // 最终结果 1 0 -1
                map.put("goods", String.valueOf(notes.getGoods() - 1));
            }
        } else if (nl.getStatus() == 0) {
            UpdateWrapper<Notes> updateWrapper = new UpdateWrapper<>();
            updateWrapper.set("goods", notes.getGoods() + status);
            updateWrapper.eq("id", notesid);
            notesMapper.update(notes, updateWrapper);

            // 修改一下noteslike行的status
            UpdateWrapper<NotesLike> updateWrapper1 = new UpdateWrapper<>();
            updateWrapper1.set("status", status);
            updateWrapper1.eq("id", nl.getId());
            notesLikeMapper.update(nl, updateWrapper1);

            if (status == 1) {
                map.put("status", String.valueOf(1)); // 最终结果 1 0 -1
                map.put("goods", String.valueOf(notes.getGoods() + 1));
            }
            if (status == -1) {
                map.put("status", String.valueOf(-1)); // 最终结果 1 0 -1
                map.put("goods", String.valueOf(notes.getGoods() - 1));
            }
        }
        else { // 说明存在 则进行状态查询
            if (!Objects.equals(nl.getStatus(), status)) { // 这个时候需要变动
                UpdateWrapper<Notes> updateWrapper = new UpdateWrapper<>();
                updateWrapper.set("goods", notes.getGoods() + status);
                updateWrapper.eq("id", notesid);
                notesMapper.update(notes, updateWrapper);

                // 修改一下noteslike行的status
                UpdateWrapper<NotesLike> updateWrapper1 = new UpdateWrapper<>();
                updateWrapper1.set("status", 0);
                updateWrapper1.eq("id", nl.getId());
                notesLikeMapper.update(nl, updateWrapper1);

                // 说明状态变成0了
                if (status == 1) {
                    map.put("status", String.valueOf(0)); // 最终结果 1 0 -1
                    map.put("goods", String.valueOf(notes.getGoods() + 1));
                }
                if (status == -1) {
                    map.put("status", String.valueOf(0)); // 最终结果 1 0 -1
                    map.put("goods", String.valueOf(notes.getGoods() - 1));
                }
            } else { // 说明无事发生啊
                map.put("status", String.valueOf(status)); // 最终结果 1 0 -1
                map.put("goods", String.valueOf(notes.getGoods()));
            }
        }

        map.put("error_message", "success");

        return map;
    }
}
