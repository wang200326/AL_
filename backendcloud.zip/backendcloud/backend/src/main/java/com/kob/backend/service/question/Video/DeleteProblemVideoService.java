package com.kob.backend.service.question.Video;

import java.util.Map;

public interface DeleteProblemVideoService {
    public Map<String, String> deleteProblemVideo(Map<String, String> data);
}
