package com.kob.backend.controller.course.CourseReply;

import com.kob.backend.service.course.CourseReply.DeleteCourseReplyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
public class DeleteCourseReplyController {
    @Autowired
    private DeleteCourseReplyService deleteCourseReplyService;
    @PostMapping("/courseReply/delete/")
    public Map<String, String> deleteCourseReply(@RequestParam Map<String, String> data) {
        return deleteCourseReplyService.deleteCourseReply(data);
    }
}
