package com.kob.backend.service.course.CourseTalk;

import java.util.Map;

public interface DeleteCourseTalkService {
    public Map<String, String> deleteCourseTalk(Map<String, String> data);
}
