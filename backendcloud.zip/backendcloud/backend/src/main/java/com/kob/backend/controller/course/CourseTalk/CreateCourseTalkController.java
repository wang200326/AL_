package com.kob.backend.controller.course.CourseTalk;

import com.kob.backend.service.course.CourseTalk.CreateCourseTalkService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
public class CreateCourseTalkController {
    @Autowired
    private CreateCourseTalkService createCourseTalkService;
    @PostMapping("/courseTalk/create/")
    public Map<String, String> createCourseTalk(@RequestParam Map<String, String> data) {
        return createCourseTalkService.createCourseTalk(data);
    }
}
