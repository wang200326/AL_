package com.kob.backend.component.utils;

import com.kob.backend.utils.JwtUtil;
import io.jsonwebtoken.Claims;

public class Jwt {
    public static Integer getUserId(String token) {
        int userid;
        try {
            Claims claims = JwtUtil.parseJWT(token);
            userid = Integer.parseInt(claims.getSubject());
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        return userid;
    }
}
