package com.kob.backend.service.impl.postMessage.MessageReply;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.kob.backend.mapper.postMessage.MessageReplyMapper;
import com.kob.backend.pojo.postMessage.MessageReply;
import com.kob.backend.service.postMessage.MessageReply.ReadMessageReplyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Queue;

@Service
public class ReadMessageReplyServiceImpl implements ReadMessageReplyService {
    @Autowired
    private MessageReplyMapper messageReplyMapper;
    @Autowired
    private ObjectMapper objectMapper;
    @Override
    public Map<String, String> readMessageReply(Map<String, String> data) throws JsonProcessingException {
        Map<String, String> map = new HashMap<>();

        Integer message_id = Integer.valueOf(data.get("messageId"));

        QueryWrapper<MessageReply> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("message_id", message_id);
        queryWrapper.orderByDesc("create_time");

        List<MessageReply> list = messageReplyMapper.selectList(queryWrapper);

        if (list.isEmpty()) {
            map.put("error_message", "暂无回复");
            return map;
        }

        String value = objectMapper.writeValueAsString(list);

        map.put("error_message", "success");
        map.put("list", value);

        return map;
    }
}
