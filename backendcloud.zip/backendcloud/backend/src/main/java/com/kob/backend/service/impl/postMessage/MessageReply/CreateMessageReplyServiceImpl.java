package com.kob.backend.service.impl.postMessage.MessageReply;

import com.kob.backend.mapper.postMessage.MessageReplyMapper;
import com.kob.backend.pojo.postMessage.MessageReply;
import com.kob.backend.service.postMessage.MessageReply.CreateMessageReplyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

@Service
public class CreateMessageReplyServiceImpl implements CreateMessageReplyService {
    @Autowired
    private MessageReplyMapper messageReplyMapper;

    @Override
    public Map<String, String> createMessageReply(Map<String, String> data) {
        Map<String, String> map = new HashMap<>();

        Integer user_id = Integer.valueOf(data.get("userId"));
        String user_name = data.get("userName");
        Integer other_id = Integer.valueOf(data.get("otherId"));
        String other_name = data.get("otherName");
        String photo = data.get("photo");
        String content = data.get("content");
        String markdown = data.get("markdown");
        Integer message_id = Integer.valueOf(data.get("messageId"));

        if (Objects.equals(content, "") || content == null) {
            map.put("error_message", "内容不能为空");
            return map;
        } else if (content.length() > 8000000) {
            map.put("error_message", "内容超出上限");
            return map;
        }

        if (Objects.equals(markdown, "") || markdown == null) {
            map.put("error_message", "内容不能为空");
            return map;
        } else if (markdown.length() > 100000) {
            map.put("error_message", "内容超出上限");
            return map;
        }

        Date now = new Date();

        MessageReply messageReply = new MessageReply(
                null,
                user_id,
                user_name,
                other_id,
                other_name,
                photo,
                now,
                content,
                markdown,
                message_id
        );

        messageReplyMapper.insert(messageReply);

        map.put("error_message", "success");
        return map;
    }
}
