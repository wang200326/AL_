package com.kob.backend.controller.compete.competeProblem;

import com.kob.backend.service.compete.competeProblem.DeleteCompeteProblemService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
public class DeleteCompeteProblemController {
    @Autowired
    private DeleteCompeteProblemService deleteCompeteProblemService;

    @PostMapping("/competeProblem/delete/")
    public Map<String, String> deleteCompeteProblem(@RequestParam Map<String, String> data) {
        return deleteCompeteProblemService.deleteCompeteProblem(data);
    }
}
