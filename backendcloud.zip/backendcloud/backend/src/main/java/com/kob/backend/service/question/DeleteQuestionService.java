package com.kob.backend.service.question;

import java.util.Map;

public interface DeleteQuestionService {
    public Map<String, String> delete(Map<String, String> data);
}
