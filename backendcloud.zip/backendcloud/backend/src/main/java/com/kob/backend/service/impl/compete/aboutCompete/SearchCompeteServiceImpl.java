package com.kob.backend.service.impl.compete.aboutCompete;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.kob.backend.mapper.compete.CompeteMapper;
import com.kob.backend.mapper.compete.CompeteRegisterMapper;
import com.kob.backend.pojo.compete.Compete;
import com.kob.backend.service.compete.aboutCompete.SearchCompeteService;
import com.kob.backend.service.impl.compete.CompeteObj;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.concurrent.TimeUnit;

@Service
public class SearchCompeteServiceImpl implements SearchCompeteService {
    @Autowired
    private CompeteMapper competeMapper;
    @Autowired
    private ObjectMapper objectMapper;
    @Autowired
    private CompeteRegisterMapper competeRegisterMapper;
    @Override
    public Map<String, String> searchCompete(Map<String, String> data) throws JsonProcessingException {
        Map<String, String> map = new HashMap<>();

        // 三个String
        String input = data.get("input"); // 比赛名称
        String type = data.get("type"); // 比赛类型 全部 萌新赛 拔高赛 挑战赛
        String status = data.get("status"); // 报名状态 全部 报过名的 没报过名的
        Integer user_id = Integer.valueOf(data.get("userId")); // 用户 id

        QueryWrapper<Compete> queryWrapper = new QueryWrapper<>();

        if (Objects.equals(input, "全部")) {
            input = "";
        }

        if (Objects.equals(type, "全部")) {
            type = "";
        }
        System.err.println("input == >" + input + "\n" + "type == > " + type + "status == >" + status);
        // 使用模糊查询，匹配竞赛名称
        queryWrapper.like("title", "%" + input + "%");
        // 添加竞赛类型作为条件
        queryWrapper.like("title", "%" + type + "%");

        if (Objects.equals(status, "已报名")) {
            queryWrapper.inSql("id",
                    "SELECT c.id FROM compete c WHERE c.id IN (SELECT cr.compete_id FROM compete_register cr WHERE cr.user_id = " + user_id + ")");
        }

        if (Objects.equals(status, "未报名")) {
            queryWrapper.notInSql("id",
                    "SELECT c.id FROM compete c WHERE c.id IN " +
                            "(SELECT cr.compete_id FROM compete_register cr WHERE cr.user_id = " + user_id + ")");

        }

        List<Compete> list = competeMapper.selectList(queryWrapper); // 所有符合前两个条件的list 现在要筛选出符合第34条件的
        System.err.println(list);
        Date newDate = new Date(); // 举例：当前时间

        // 获取中国时区
        TimeZone chinaTimeZone = TimeZone.getTimeZone("Asia/Shanghai");

        // 创建 Calendar 对象，并设置为中国时区
        Calendar chinaCalendar = Calendar.getInstance(chinaTimeZone);

        // 获取当前中国时区时间
        Date currentChinaTime = chinaCalendar.getTime();

        List<CompeteObj> register = new ArrayList<>();
        List<CompeteObj> alreadyStarted = new ArrayList<>();
        List<CompeteObj> finish = new ArrayList<>();

        for (Compete item : list) {
            if (item.getStartTime().compareTo(currentChinaTime) <= 0 &&
                    item.getCloseTime().compareTo(currentChinaTime) >= 0) {

                Date startDate = item.getStartTime(); // 第一个日期对象，比如开始时间
                Date endDate = item.getCloseTime(); // 第二个日期对象，比如结束时间

                // 计算两个日期之间的时间差（毫秒数）
                long durationInMillis = endDate.getTime() - startDate.getTime();

                // 转换为小时和分钟
                long hours = TimeUnit.MILLISECONDS.toHours(durationInMillis);
                long minutes = TimeUnit.MILLISECONDS.toMinutes(durationInMillis) % 60;

                CompeteObj competeObj = new CompeteObj(
                        item.getId(),
                        item.getTitle(),
                        item.getStartTime(),
                        item.getCloseTime(),
                        item.getImage(),
                        item.getParticipant(),
                        item.getContent(),
                        hours + "小时" + minutes + "分钟"
                );

                alreadyStarted.add(competeObj);
            } else if (item.getStartTime().compareTo(currentChinaTime) > 0) {
                Date startDate = item.getStartTime(); // 第一个日期对象，比如开始时间
                Date endDate = item.getCloseTime(); // 第二个日期对象，比如结束时间

                // 计算两个日期之间的时间差（毫秒数）
                long durationInMillis = endDate.getTime() - startDate.getTime();

                // 转换为小时和分钟
                long hours = TimeUnit.MILLISECONDS.toHours(durationInMillis);
                long minutes = TimeUnit.MILLISECONDS.toMinutes(durationInMillis) % 60;

                CompeteObj competeObj = new CompeteObj(
                        item.getId(),
                        item.getTitle(),
                        item.getStartTime(),
                        item.getCloseTime(),
                        item.getImage(),
                        item.getParticipant(),
                        item.getContent(),
                        hours + "小时" + minutes + "分钟"
                );

                register.add(competeObj);
            } else {
                Date startDate = item.getStartTime(); // 第一个日期对象，比如开始时间
                Date endDate = item.getCloseTime(); // 第二个日期对象，比如结束时间

                // 计算两个日期之间的时间差（毫秒数）
                long durationInMillis = endDate.getTime() - startDate.getTime();

                // 转换为小时和分钟
                long hours = TimeUnit.MILLISECONDS.toHours(durationInMillis);
                long minutes = TimeUnit.MILLISECONDS.toMinutes(durationInMillis) % 60;

                CompeteObj competeObj = new CompeteObj(
                        item.getId(),
                        item.getTitle(),
                        item.getStartTime(),
                        item.getCloseTime(),
                        item.getImage(),
                        item.getParticipant(),
                        item.getContent(),
                        hours + "小时" + minutes + "分钟"
                );

                finish.add(competeObj);
            }
        }

        String enter = null;
        if (!register.isEmpty()) enter = objectMapper.writeValueAsString(register);
        String already = null;
        if (!alreadyStarted.isEmpty()) already = objectMapper.writeValueAsString(alreadyStarted);
        String finished = null;
        if (!finish.isEmpty()) finished = objectMapper.writeValueAsString(finish);

        map.put("error_message", "success");
        map.put("register", enter);
        map.put("already", already);
        map.put("finish", finished);

        return map;
    }
}
