package com.kob.backend.service.impl.compete.aboutCompete;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.kob.backend.mapper.compete.CompeteMapper;
import com.kob.backend.pojo.compete.Compete;
import com.kob.backend.service.compete.aboutCompete.CreateCompeteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

@Service
public class CreateCompeteServiceImpl implements CreateCompeteService {
    @Autowired
    private CompeteMapper competeMapper;

    @Override
    public Map<String, String> createCompete(Map<String, String> data) {
        Map<String, String> map = new HashMap<>();

        String title =  data.get("title");
        Long start_time = Long.valueOf(data.get("startTime"));
        Long close_time = Long.valueOf(data.get("closeTime"));
        String image = data.get("image");
        String content = data.get("content");

        if (Objects.equals(title, "") || title == null) {
            map.put("error_message", "title为空");
            return map;
        } else if (title.length() > 100) {
            map.put("error_message", "title长度不能超过100字符");
            return map;
        }

        if (Objects.equals(image, "") || image == null) {
            map.put("error_message", "image为空");
            return map;
        } else if (image.length() > 100) {
            map.put("error_message", "image长度不能超过100字符");
            return map;
        }

        if (Objects.equals(content, "") || content == null) {
            map.put("error_message", "content为空");
            return map;
        } else if (content.length() > 1000) {
            map.put("error_message", "content长度不能超过100字符");
            return map;
        }


        Date t1 = new Date(start_time);
        Date t2 = new Date(close_time);

        Compete compete = new Compete(
                null,
                title,
                t1,
                t2,
                image,
                0,
                content
        );

        competeMapper.insert(compete);

        map.put("error_message", "success");
        return map;
    }
}
