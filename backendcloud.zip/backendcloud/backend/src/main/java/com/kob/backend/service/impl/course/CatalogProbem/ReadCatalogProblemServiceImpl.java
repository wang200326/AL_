package com.kob.backend.service.impl.course.CatalogProbem;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.kob.backend.mapper.course.CatalogProblemMapper;
import com.kob.backend.pojo.course.CatalogProblem;
import com.kob.backend.service.course.CatalogProblem.ReadCatalogProblemService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class ReadCatalogProblemServiceImpl implements ReadCatalogProblemService {
    @Autowired
    private CatalogProblemMapper catalogProblemMapper;
    @Autowired
    private ObjectMapper objectMapper;

    @Override
    public Map<String, String> ReadCatalogProblem(Map<String, String> data) throws JsonProcessingException {
        Map<String, String> map = new HashMap<>();

        String Catalog_id = data.get("catalogId");
        if (Catalog_id == "" || Catalog_id == null) {
            map.put("error_message", "目录id为空");
            return map;
        }
        Integer catalog_id = Integer.valueOf(Catalog_id);

        QueryWrapper<CatalogProblem> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("catalog_id", catalog_id);
        queryWrapper.orderByAsc("title");
        List<CatalogProblem> list = catalogProblemMapper.selectList(queryWrapper);
        if (list.isEmpty()) {
            map.put("error_message", "当前目录没有对应的习题");
            return map;
        }
        String value = objectMapper.writeValueAsString(list);

        map.put("error_message", "success");
        map.put("catalogProblem", value);
        return map;
    }
}
