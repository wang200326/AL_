package com.kob.backend.controller.user.account;

import com.kob.backend.service.user.account.DeleteUserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
public class DeleteUserController {
    @Autowired
    private DeleteUserService deleteUserService;
    @PostMapping("/user/delete/")
    public Map<String, String> deleteUser(@RequestParam Map<String, String> data) {
        return deleteUserService.deleteUser(data);
    }
}
