package com.kob.backend.service.impl.course.Video;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.kob.backend.mapper.course.CatalogMapper;
import com.kob.backend.mapper.course.CourseVideoMapper;
import com.kob.backend.pojo.course.CourseVideo;
import com.kob.backend.service.course.Video.CreateCourseVideoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

@Service
public class CreateCourseVideoServiceImpl implements CreateCourseVideoService {
    @Autowired
    private CourseVideoMapper courseVideoMapper;
    @Autowired
    private CatalogMapper catalogMapper;

    @Override
    public Map<String, String> createVideo(Map<String, String> data) {
        Map<String, String> map = new HashMap<>();

        String Catalog_id = data.get("catalogId");
        String url = data.get("url");
        String title = data.get("title");
        String Number = data.get("number");

        if (Objects.equals(Catalog_id, "") || Catalog_id == null) {
            map.put("error_message", "目录id不能为空");
            return map;
        }

        if (Objects.equals(url, "") || url == null) {
            map.put("error_message", "url不能为空");
            return map;
        } else if (url.length() > 100) {
            map.put("error_message", "url不能超过100个字符");
            return map;
        }

        if (Objects.equals(title, "") || title == null) {
            map.put("error_message", "title不能为空");
            return map;
        } else if (title.length() > 100) {
            map.put("error_message", "title不能超过100个字符");
            return map;
        }

        if (Objects.equals(Number, "") || Number == null) {
            map.put("error_message", "课程编号number不能为空");
            return map;
        }

        Integer catalog_id = Integer.valueOf(Catalog_id);
        Integer number = Integer.valueOf(Number);

        if (catalogMapper.selectById(catalog_id) == null) {
            map.put("error_message", "目录不存在");
            return map;
        }

        if ( number <= 0 ) {
            map.put("error_message", "number超出范围");
            return map;
        }

        QueryWrapper<CourseVideo> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("catalog_id", catalog_id);
        queryWrapper.eq("number", number);
        if (courseVideoMapper.selectOne(queryWrapper) != null) {
            map.put("error_message", "number已经存在了");
            return map;
        }

        CourseVideo courseVideo = new CourseVideo(
                null,
                catalog_id,
                url,
                title,
                number
        );
        courseVideoMapper.insert(courseVideo);

        map.put("error_message", "success");
        return map;
    }
}
