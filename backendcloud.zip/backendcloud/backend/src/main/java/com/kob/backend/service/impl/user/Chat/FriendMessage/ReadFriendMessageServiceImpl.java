package com.kob.backend.service.impl.user.Chat.FriendMessage;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.kob.backend.mapper.Chat.friend_message.FriendMessageMapper;
import com.kob.backend.pojo.Chat.friend_message.FriendMessage;
import com.kob.backend.service.user.Chat.FriendMessage.ReadFriendMessageService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class ReadFriendMessageServiceImpl implements ReadFriendMessageService {
    @Autowired
    private FriendMessageMapper friendMessageMapper;
    @Autowired
    private ObjectMapper objectMapper;
    @Override
    public Map<String, String> readFriendMessage(Map<String, String> data) throws JsonProcessingException {
        Map<String, String> map = new HashMap<>();

        Integer user_id = Integer.valueOf(data.get("userId"));
        Integer other_id = Integer.valueOf(data.get("otherId"));

        QueryWrapper<FriendMessage> queryWrapper = new QueryWrapper<>();
        queryWrapper.and(qw -> qw.eq("user_id", user_id).eq("other_id",other_id)
                .or(i -> i.eq("user_id", other_id).eq("other_id", user_id)
        ));

        List<FriendMessage> list = friendMessageMapper.selectList(queryWrapper);

        if (list.isEmpty()) {
            map.put("error_message", "这两个家伙没有聊过天");
            return map;
        }

        String value = objectMapper.writeValueAsString(list);

        map.put("error_message", "success");
        map.put("list", value);
        return map;
    }
}
