package com.kob.backend.service.compete.aboutCompete;

import com.fasterxml.jackson.core.JsonProcessingException;

import java.util.Map;

public interface CountCompeteService {
    public Map<String, String> countCompete() throws JsonProcessingException;
}
