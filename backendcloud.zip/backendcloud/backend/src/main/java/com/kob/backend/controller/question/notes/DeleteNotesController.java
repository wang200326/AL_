package com.kob.backend.controller.question.notes;

import com.kob.backend.service.question.notes.DeleteNotesService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
public class DeleteNotesController {
    @Autowired
    private DeleteNotesService deleteNotesService;

    @PostMapping("/notes/delete/")
    public Map<String, String> deleteNotes(@RequestParam Map<String, String> data) {
        return deleteNotesService.deleteNotes(data);
    }
}
