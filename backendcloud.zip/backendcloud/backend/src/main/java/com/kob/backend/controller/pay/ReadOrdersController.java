package com.kob.backend.controller.pay;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.kob.backend.service.pay.ReadOrdersService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
public class ReadOrdersController {
    @Autowired
    private ReadOrdersService readOrdersService;
    @PostMapping("/orders/read/")
    public Map<String, String> readOrders(@RequestParam Map<String, String> data) throws JsonProcessingException {
        return readOrdersService.readOrders(data);
    }
}
