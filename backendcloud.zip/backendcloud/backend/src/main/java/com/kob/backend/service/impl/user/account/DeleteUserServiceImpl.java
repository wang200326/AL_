package com.kob.backend.service.impl.user.account;

import com.kob.backend.mapper.UserMapper;
import com.kob.backend.service.user.account.DeleteUserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

@Service
public class DeleteUserServiceImpl implements DeleteUserService {
    @Autowired
    private UserMapper userMapper;
    @Override
    public Map<String, String> deleteUser(Map<String, String> data) {
        Map<String, String> map = new HashMap<>();

        Integer id = Integer.valueOf(data.get("id"));

        userMapper.deleteById(id);

        map.put("error_message", "success");

        return map;
    }
}
