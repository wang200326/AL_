package com.kob.backend.service.question;

import com.fasterxml.jackson.core.JsonProcessingException;

import java.util.Map;

public interface GetOneQuestionService {
    public Map<String, String> getOne(Map<String, String> data) throws JsonProcessingException;
}
