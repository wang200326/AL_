package com.kob.backend.controller.course.CourseTalk;

import com.kob.backend.service.course.CourseTalk.DeleteCourseTalkService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
public class DeleteCourseTalkController {
    @Autowired
    private DeleteCourseTalkService deleteCourseTalkService;
    @PostMapping("/courseTalk/delete/")
    public Map<String, String> deleteCourseTalk(@RequestParam Map<String, String> data) {
        return deleteCourseTalkService.deleteCourseTalk(data);
    }
}
